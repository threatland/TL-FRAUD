==========================================================================
xTSCrack - Version 0.9
RDP Audit Tool
==========================================================================

1 - Introduction

xTSCrack is a simple RDP Audit tool for Penentration Tester find weak
passwords over RDP protocol. xTSCrack support Windows 2000, XP, 2003
and 2008 Terminal Service.

2 - What's new?

+ Stop process bug fixed;
+ Multiple users password recovery bug fixed;
+ Logoff after logon success added;
+ Import hosts option added;
+ Exceptions fixed;
+ Manual modified;
+ Interface modified.

Version 0.8

- New target option added;
- Save Results bug fixed.

Version 0.7

- New interface added;
- Multi-host support added.

Version 0.6

- Supported clients: Windows 2000, XP, Vista, 2003 and 7
- Supported servers: Windows 2000, Windows XP, Windows 2003 and Windows 2008
- Port field added;
- Stop bug fixed.

Version 0.5

- Domain field lock fixed;
- Dispose bug fixed;
- Crash fixed.

Version 0.4

- First public release;
- New attack method added;
- Bugs fixed;
- RDP Legal Notice support added.

Version 0.3

- Manual created;
- Tested in Windows 2003 e Windows 2008;
- New attack method added;
- Beta version launched for private users only.

Version 0.2

- Bugs fixed;
- New visual added;
- Windows XP support added.

Version 0.1

- Alpha version launched for private users only.

3 - Credits

Thx to Neil Tischinae to report the bug of domain field and the crash after new scan.
Thx to Alexandre Souza to report dispose problem and help me with tests.
Thx to root from cnmoker for suggestions.

4 - Contact

_sector_x@hackermail.com or rodrigomatuck@globo.com