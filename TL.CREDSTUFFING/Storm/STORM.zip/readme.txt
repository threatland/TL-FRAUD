DISCLAIMER!
STORM is a cracking program designed to perform website security testing.
The Author and Cracking.org are not responsible for any illegal use of this program.

About STORM
The project started on January 2018 by MR.ViPeR.
Special thanks to: Cracking.org staff and m1st (Beta Tester).