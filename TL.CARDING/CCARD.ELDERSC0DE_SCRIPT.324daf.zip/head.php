<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <!-- Bootstrap -->
        <link href="/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="/assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="/">Akatsuki-ID</a>

                        <ul class="nav">
                            <li class="">
                                <a href="/">Dashboard</a>
                            </li>

                            <li class="dropdown">
                                
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Content <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="http://www.akatsuki-id.net" target="blank">Blog</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="https://facebook.com/yadi365" target="blank">Facebook</a>
                                    </li>
                                </ul>
                            </li>

                            <ul class="nav">
                            <li class="">
                                <a href="/order">Order</a>
                            </li>
                    </div>                                   
                    <!--/.nav-collapse -->
                </div>
          </div>         
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li class="active">
                            <a href="/"><i class="icon-chevron-right"></i><i class="icon-home"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="https://facebook.com/yadi365" target="_blank"><i class="icon-chevron-right"></i><i class="icon-user"></i> Contact Admin</a>
                        </li>
                        <li>
                            <a href="/check"><i class="icon-th"></i></span><span> Account Checker</span></a>
                        </li>
                        <li>
                            <a href="/email"><i class="icon-th"></i></span><span> Email Valid Checker</span></a>
                        </li>
                        <li>
                            <a href="/card"><i class="icon-th"></i></span><span> Card Checker </span></a>
                        </li>
                        <li>
                            <a href="/other"><i class="icon-th"></i></span><span> Other Tools </a>
                        </li>
                        <li>
                            <a href="/order"><i class="icon-th"></i></span><span> Order </a>
                        </li>
                        <li>
                            <a href="/method"><i class="icon-th"></i></span><span> Method </a>
                        </li>
                    </ul>
                </div>

<br><br>
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        
                        	<div class="navbar">