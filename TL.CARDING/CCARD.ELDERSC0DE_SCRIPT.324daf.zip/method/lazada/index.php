<?php 
include('../../head.php');
?>
<title>Method Lazada</title>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Method Lazada</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<center><b>
========================<br>
SEBELUM GUNAKAN TUTOR<br>
========================<br>
[-] Clear Cache Browser Anda.<br>
[-] Pakai VPN / RDP.<br>
[-] Siapin CC.<br>
=============<br>
Pendahuluan<br>
=============<br>
1. Pastikan lu punya CC dengan bin yang joss<br>
2. Bikin Akun Lazada Yang Baru/Fresh<br>
=======<br>
Tutor<br>
=======<br>
[-] Atur VPN / RDP<br>
[-] Buka Site Lazada<br>
[-] Pilih barang<br>
[-] Checkout pakai akun baru<br>
[-] Masukan alamat lalu menuju pembayaran<br>
[-] Masukin CC nya sama datanya (nama tidak penting)<br>
[-] Klik checkout, dan sukses ^^<br>
[-] Kalo gabisa berarti amal baik lo kurang / FF<br>

</b></center><center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
</body>
</html>