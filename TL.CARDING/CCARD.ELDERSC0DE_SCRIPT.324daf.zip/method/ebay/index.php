<?php 
include('../../head.php');
?>
<title>Method Ebay</title>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Method Ebay</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<center><b>
========================<br>
SEBELUM GUNAKAN TUTOR<br>
========================<br>
[-] Clear Cache Browser Anda.<br>
[-] Pakai VPN / RDP.<br>
[-] PP HB+HC+LT.<br>
[-] Buka paypal.com Lalu Login.<br>
[-] Ganti Address Ebay Biar Sama Kyk Alamat di Paypal.<br>
=============<br>
Pendahuluan<br>
=============<br>
1. Bikin Akun Ebay Yang Baru/Fresh [Kalo Misalnya Akun Fresh, Seller Seller bisa di Bujuk]<br>
2. Milih Seller Ebay Yang Feedback nya di Baawah 100 ( Misal 80-90 Feedback Biasanya ) Seller Yang Newbie Ngga Memperhatikan Rules EBAY.<br>
=======<br>
Tutor<br>
=======<br>
[-] Atur VPN / RDP<br>
[-] Atur Time Zone<br>
[-] Buka Site Ebay<br>
[-] Milih Barang > Checkout<br>
[-] Klik Change Shipping Address Pastikan Sudah Sama Seperti di Paypal<br>
[-] Masukkan GC Linked<br>
[-] Klik Continue<br>
[-] Masukkan Email + Password Paypal<br>
[-] Nanti Akan Muncul GC Linked Yang Tadi di Pakai.<br>
[-] Lalu Akan Munculin Log-log no 2&3<br>
[-] Success<br>
[-] Jangan Lupa Contact Seller!!</b></center><center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
</body>
</html>