<?php
session_start();

if (empty($_SESSION['email'])){
header('location: /account'); 
}

$link = "http://amex-team.ml/";
include('../../account/login/auth.php');
                  
                    $email = $_SESSION['email'];
                    $query = "SELECT * FROM user WHERE email='$email'";
                    $exe = mysql_query($query);
                    $no = 1;
                    while($row = mysql_fetch_assoc($exe)){
                        $invite = $row['regby']; 
                        $credits = $row['credits'];    
                        $banned = $row['banned'];                    
                        $admin = $row['admin']; 
                        $orders = $row['orders']; 
                    }
$cekuser = mysql_query("SELECT * FROM user WHERE email = '".$_SESSION["email"]."'");
$jumlah = mysql_num_rows($cekuser);
if($jumlah == 0) {
session_destroy();
header('location: /account/');
}
if ($banned == 1) {
session_destroy();
header('location: /account/banned');
}
include "functions.php";


?>
<html>
<head>
<style>
			body
		{
			background-color: rgb(74,81,85);
			font-size: 9pt;
			font-family:Verdana;
			line-height:12pt;
			color: #cccccc;
		}
			body,td,th {
			color: #99CC00;
		}
		h2
		{
			color: #FFCC00;
		}
		h1 {
			padding: 10px 15px;
			color: red;
		}

		.main-content {
				width: 70%; height: 380px;margin: auto; background: rgb(74,81,85);      border-radius: 5px 5px 5px 5px; box-shadow: 0 0 3px rgba(0, 0, 0, 0.5); min-height: 380px;      position: relative;
		}
		textarea, input {
				border-radius: 5px 5px 5px 5px;
		}
		input {
				height: 30px;width: 150px;text-align: center;o
		}
			
			
		.button {
			   
		}
		
	</style>
<title>ANUAN CHECKER</title></head>
<body>
<script type="text/javascript">
function fucksock(){
var cvvlist = window.document.frm.listsocks.value;
var fuck = cvvlist.match(/\d{6}/g );
if(fuck){
var list="";
for(var i=0;i<fuck.length;i++){
list=list+fuck[i]+"\n";
}
window.document.frm.listsocks.value=list;
}
else{
window.document.frm.listsocks.value="Not found";
}
}
</script><center>
<h1>FILTER BIN 6 NUM</h1>
<form name="frm" action="" method=POST>
<textarea name=listsocks cols=100 rows=15></textarea><br><br>
<input type=button value="CHECKER NOW" onclick="fucksock(); return false;">
</form></center>
</body>
</html>