<?php
include('../head.php');
?>
                     
                        	<div class="navbar">
        <title>Account Checker - Akatsuki-ID</title>


                    <div class="row-fluid">
		                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Account Checker</b></center></div>
                                </div>

                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Status</th>
                                                <th>About</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="apple">Apple Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="alibaba">Alibaba Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="amz">Amazon Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="afraid">Afraid Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="balao">Balao Da Informatica Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>6</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="balao">Dafini Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>7</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="fastshop">Fastshop Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>8</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="nordstrom">Nordstrom Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>9</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="oasgames">Oasgames Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>10</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="hostgator">Hostgator Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>11</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="terra">Terra Account Checker</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>12</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="pepe">Paypal Account Checker With Token</a></b></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            
        </div>
        <!--/.fluid-container-->
        <script src="vendors/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="assets/scripts.js"></script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>
    </body>

</html>