<?php
include('../../head.php')
?>

<html>
<head><link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<title>Paypal Account Checker</title>

<head><link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
        <style>
                @import "http://fonts.googleapis.com/css?family=Play:400,700";
                        
                       
                        body {
                        .char { 
                          transition: all 5s; -webkit-transition: all 1s;
                          opacity: 0.8;
                        }
                        .char:hover {
                          transition: all 0.1s; -webkit-transition: all 0.1s;
                          opacity:1.5;
                          text-shadow: 0 0 1em white;
                        }
                        .chara:not(.space):hover {
                          transform: rotateY(1440deg);
                          -webkit-transform: rotateY(1440deg);
                        }
                        .chara:not(.space) {
                          display: inline-block;
                          transition: transform 2s ease-out;
                          -webkit-transition: -webkit-transform 2s ease-out;
                        }
                        
@-webkit-keyframes progress { 
    from { }

    to { width: 100% }
}

@-moz-keyframes progress { 
    from { }

    to { width: 100% }
}

@-ms-keyframes progress { 
    from { }

    to { width: 100% }
}

@keyframes progress { 
    from { }

    to { width: 100% }
}

body,td,th {
        color:  gold;
        }
</style>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="Paypal Account Checker" />
    <meta name="author" content="Akatsuki" />
    <title>PayPal Account Checker</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
    <script type="text/javascript" src="blockui.js"></script>

</head>
<body>
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Paypal Account Checker</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<form method="post">
    <div align="center">
        <textarea placeholder="example@email.com|Password" name="mailpass" id="mailpass" cols="60" rows="10" style="margin: 0px 0px 10px; width: 494px; height: 200px;"></textarea>
        <br /><br />
        <b>Delim:</b> <input type="text" name="delim" id="delim" value="|"  cols="30" rows="10" style="margin: 0px; height: 20px; width: 10px;" /><br><input placeholder='Enter Access Token Here'  type="text" name="token" id="token" value="" size="40" style="margin-top: 5px;background:rgba(225,225,225,0.2);text-align:center" /><br>
<br />
<p class="rainbow">
                Check Email <input type="checkbox"  id="checkEmail" name="checkEmail" checked="checked" value="1" />
                Check Bank <input type="checkbox" id="bank"  name="bank" checked="checked" value="1" />
                Check Card <input type="checkbox" id="card"  name="card" checked="checked" value="1" />
                Get Info <input type="checkbox"  id="info" name="info" checked="checked" value="1" />
                Get Recently Payed <input type="checkbox"  id="payment" name="payment" checked="checked" value="1" />
                Get Phone Number <input type="checkbox"  id="phone" name="phone" checked="checked" value="1" />
                <!--Auto Send <input type="checkbox"  id="send" name="send"  value="1" />--> 
                </p>
<br>             
        <input type="button" class = "btn btn-success" value="START" id="submit" />&nbsp;<input type="button" class="btn btn-danger" value="STOP" id="stop" /><br><br/>
        <img id="loading" style="display: none;">
        <img id="loading" src="clear.gif" /><br />
        <span id="checkStatus" style="color: limegreen;"></span>
    </div>
</form>
<center>
<div id='buy' style="width: 500px;border:1px dashed yellow;"><hr>
<h4><font color="gold" > .============[ <img src='token.png'> ]============. </font></h4>                 
<html>
<script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
<textarea name="data" id="data" cols="5" rows="10" style="width: 462px; margin: 0px 0px 5px; height: 161px;">
<?php

function bacaHTML($url){
     // inisialisasi CURL
     $data = curl_init();
     // setting CURL
     curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($data, CURLOPT_URL, $url);
     // menjalankan CURL untuk membaca isi file
     $hasil = curl_exec($data);
     curl_close($data);
     return $hasil;
}
echo bacaHTML('http://akatsuki-id.club/token.php');

?>
</textarea>
<h5><font size="3" color="gold"> .============================================. </font></h5>
</div></center>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                                </div>
                            </div>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Live </b></font><span class="badge badge-success" class="pull-right" id="clive">0</span>
</div>
                                </div>
                                <div class="block-content collapse in">
                        <div id="pplive">
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Die </b></font><span class="badge badge-important" class="pull-right" id="ppdie_count">0</span></div>
                                </div>
                                <div class="block-content collapse in">
<div id="ppdie"></div>
</div>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                                </div>
                            </div>

</body>
</html>      
<script type="text/javascript" src="script.js"></script>
</body>
</html>
<br>