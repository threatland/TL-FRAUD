
<html>
<head><title>ANUAN CHECKER</title>
<style type="text/css">
</style>
</head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body{background-color: #333333;}
body,td,th {color: #99CC00;}
table {border: #00CCCC 3px dashed;}
h3{color: #FFCC00;}
A:link {Font-family:Arial,Helvetica; size:13pt; color:blue; Text-Decoration:none;}
A:hover {Color:red;Text-Decoration:Underline;}
.style1 {Color:red;Text-Decoration:overline;font-weight:bold;}
.style2{background-color:#000;}
</style>
<body>
<script type="text/javascript" src="http://widgets.amung.us/tab.js"></script><script type="text/javascript">WAU_tab('6g2jet40tllo', 'bottom-center')</script>
 <table width="100%" align="center" border="0">
    <tbody><tr>
	<td align="center">
<h2>FILTER CC DUPLICATE</h2>
<h3>Auto Get Info Credits Card</h3>
<?php
function inStr($s,$as){ 
    $s=strtoupper($s); 
    if(!is_array($as)) $as=array($as); 

    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true; 
    return false; 
} 
function info($ccline){ 
  $xy = array("|","\\","/","-",";"); 
  $sepe = $xy[0]; 
  foreach($xy as $v){ 
      if (substr_count($ccline,$sepe) < substr_count($ccline,$v)) $sepe = $v; 
  } 
  $x = explode($sepe,$ccline); 
  foreach($xy as $y) $x = str_replace($y,"",str_replace(" ","",$x)); 
  foreach ($x as $xx){ 
      $xx = trim($xx); 
         if (is_numeric($xx)){ 
             $yy=strlen($xx); 
             switch ($yy){ 
                 case 15: 
                     if (substr($xx,0,1)==3){ 
                         $ccnum['num'] = $xx; 
                         $ccnum['type'] = "American+Express"; 
                    } 
                     break; 
                 case 16: 
                     switch (substr($xx,0,1)){ 
                          case '4': 
                             $ccnum['num']=$xx; 
                             $ccnum['type'] = "VISA"; 
                             break; 
                        case '5': 
                             $ccnum['num']=$xx; 
                             $ccnum['type'] = "Mastercard"; 
                             break; 
                         case '6': 
                             $ccnum['num']=$xx; 
                             $ccnum['type'] = "Discover"; 
                             break; 
                     } 
                     break; 

              } 
          } 
          } 
    if (isset($ccnum['num'])){ 
        return $ccnum; 
    } 
    else return false; 
		
} 

function _dup($cclist){ 
    for ($i = 0;$i < count($cclist); $i++){ 
        switch($option) {
	case 0:
	$ccnum = info($cclist[$i]);
	break;
	case 1:
	$ccnum = info1($cclist[$i]);
	break;
		}
        if ($ccnum){ 
            $cc = $ccnum['num']; 
            for ($j = $i + 1;$j < count($cclist); $j++){ 
                if (inStr(str_replace("-","",str_replace(" ","",$cclist[$j])),$cc)){
				$cclist[$j] = ""; 
				}
            } 
        } 
    } 
    foreach($cclist as $i => $cc) if ($cc == "") unset($cclist[$i]); 
    $ok = array_values($cclist); 
    return $ok; 
	
} 
function percent($num_amount, $num_total) { 
$count1 = $num_amount / $num_total; 
$count2 = $count1 * 100; 
$count = number_format($count2, 0); 
return $count; 
} 
?>
<div align="center">
<form action="" method="POST" >
<textarea name="cclist"  wrap="off" style="width:90%;" rows="10" ><? echo $_REQUEST['cclist'];?></textarea>

<input type=submit name=submit value="Remove Dupe Credits Card !">
</form>
 </div>
<?
echo "</div><hr border=1><div align=left>";
if($_POST['cclist']){
	$cclist = $_POST['cclist'];
	$cclist = explode("\n",$cclist);
	$ccdupe = _dup($cclist);
	$xx = percent(count($ccdupe),count($cclist));
	echo"<center><font color=red><b>".count($ccdupe)." ~ ".$xx."%<b></font></center>";
	echo('<div align="left">');
	foreach ($ccdupe as $ccline){
	$ccnum = info($ccline);
        if ($ccnum){ 
	 echo "<font color=yellow><b>".$ccline."</b></font><br>";
	 }
	 }
	echo('</div>');
}
?>
<hr border="1">
<div align="center">
<h3>ANUAN CHECKER - [WwW.incunaspiderman.cf]</h3>
<script src="http://widgets.amung.us/small.js" type="text/javascript"></script><script type="text/javascript">WAU_small('6g2jet40tllo')</script>
</div>
</td></tr>
</tbody>
</table>
</body>
</html>