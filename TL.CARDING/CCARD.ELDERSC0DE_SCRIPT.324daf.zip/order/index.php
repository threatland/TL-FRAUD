<?php
include('../head.php');
?>
                     
                        	<div class="navbar">
        <title>Sell - Akatsuki-ID</title>

<div class="alert alert-success">
							
							<strong>Need Seller Trusted!!</strong> Contact Admin Untuk Mendaftar Menjadi Seller + Kasih Bukti Konsumen :v  
						</div>
                    <div class="row-fluid">
		                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Sell</b></center></div>
                                </div>

                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>About</th>
                                                <th>Price</th>
                                                <th>Stock</th>
                                                <th>Contact</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><b>WHM</a></b></td>
                                                <td><b>30k/bln</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td><b>Cpanel</a></b></td>
                                                <td><b>10k/bln</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td><b>PP HB+HC+LT</a></b></td>
                                                <td><b>15k/2pp</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td><b>Paketan Scampage Full</a></b></td>
                                                <td><b>100k</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/krisna.answe.52">Krisna Answer</a>Or <a href="http://facebook.com/fatur.terpercaya">Fatur Rachman Alkahfi</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td><b>Paketan Scampage Not Full</a></b></td>
                                                <td><b>60k</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/krisna.answe.52">Krisna Answer</a>Or <a href="http://facebook.com/fatur.terpercaya">Fatur Rachman Alkahfi</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>6</td>
                                                <td><b>Domain</a></b></td>
                                                <td><b>40k/th</a></b></td>
                                                <td><b>Not Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>7</td>
                                                <td><b>ZM-Panel</a></b></td>
                                                <td><b>15k</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>8</td>
                                                <td><b>CC Full Info</a></b></td>
                                                <td><b>100k/1cc</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/jinseonkun">Dimas Bartive Glow'x</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>9</td>
                                                <td><b>RDP Admin</a></b></td>
                                                <td><b>100k/bln</a></b></td>
                                                <td><b>Not Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>10</td>
                                                <td><b>RDP User</a></b></td>
                                                <td><b>40k/bln</a></b></td>
                                                <td><b>Not Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>11</td>
                                                <td><b>Pembuatan All Phising</a></b></td>
                                                <td><b>20k/bln</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>12</td>
                                                <td><b>HMA</a></b></td>
                                                <td><b>60k/bln</a></b></td>
                                                <td><b>Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/oke.co.id">Julian Cardozo</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>13</td>
                                                <td><b>VIP72</a></b></td>
                                                <td><b>100k/bln</a></b></td>
                                                <td><b>Not Ready</a></b></td>
                                                <td><b><a href="http://facebook.com/yadi365">Admin</a></b></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            
        </div>
        <!--/.fluid-container-->
        <script src="vendors/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="assets/scripts.js"></script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>
    </body>

</html>