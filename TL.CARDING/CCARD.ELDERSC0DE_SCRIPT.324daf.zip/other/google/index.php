<?php 
include('../../head.php');
?>
        <title>Google Dorking</title>
        <link rel='shortcut icon' type='image/x-icon' href='/favicon.ico' />
<link rel="stylesheet" href="//octicons.github.com/components/octicons/octicons/octicons.css">
        
        <center>
                 <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Google Dorking</b></center></div>
                                </div>
                                <div class="block-content collapse in">       
<form action="" method="post">
<input type="txt" class="dap_text_box" name="dork" placeholder="inurl:admin.php intitle:admin"><br><br>
<select name="country" id="country">
    <option value="" selected="selected">SEMUA NEGARA</option>
    <option value=" site:DZ">Algeria</option>
    <option value=" site:AD">Andorra</option>
    <option value=" site:AO">Angola</option>
    <option value=" site:AI">Anguilla</option>
    <option value=" site:AG">Antigua & Barbuda</option>
    <option value=" site:AR">Argentina</option>
    <option value=" site:AM">Armenia</option>
    <option value=" site:AW">Aruba</option>
    <option value=" site:AU">Australia</option>
    <option value=" site:AT">Austria</option>
    <option value=" site:AZ">Azerbaijan</option>
    <option value=" site:BS">Bahamas</option>
    <option value=" site:BH">Bahrain</option>
    <option value=" site:BB">Barbados</option>
    <option value=" site:BY">Belarus</option>
    <option value=" site:BE">Belgium</option>
    <option value=" site:BZ">Belize</option>
    <option value=" site:BJ">Benin</option>
    <option value=" site:BM">Bermuda</option>
    <option value=" site:BT">Bhutan</option>
    <option value=" site:BO">Bolivia</option>
    <option value=" site:BA">Bosnia & Herzegovina</option>
    <option value=" site:BW">Botswana</option>
    <option value=" site:BR">Brazil</option>
    <option value=" site:VG">British Virgin Islands</option>
    <option value=" site:BN">Brunei</option>
    <option value=" site:BG">Bulgaria</option>
    <option value=" site:BF">Burkina Faso</option>
    <option value=" site:BI">Burundi</option>
    <option value=" site:KH">Cambodia</option>
    <option value=" site:CM">Cameroon</option>
    <option value=" site:CA">Canada</option>
    <option value=" site:CV">Cape Verde</option>
    <option value=" site:KY">Cayman Islands</option>
    <option value=" site:TD">Chad</option>
    <option value=" site:CL">Chile</option>
    <option value=" site:C2">China</option>
    <option value=" site:CO">Colombia</option>
    <option value=" site:KM">Comoros</option>
    <option value=" site:CG">Congo - Brazzaville</option>
    <option value=" site:CD">Congo - Kinshasa</option>
    <option value=" site:CK">Cook Islands</option>
    <option value=" site:CR">Costa Rica</option>
    <option value=" site:CI">Côte d’Ivoire</option>
    <option value=" site:HR">Croatia</option>
    <option value=" site:CY">Cyprus</option>
    <option value=" site:CZ">Czech Republic</option>
    <option value=" site:DK">Denmark</option>
    <option value=" site:DJ">Djibouti</option>
    <option value=" site:DM">Dominica</option>
    <option value=" site:DO">Dominican Republic</option>
    <option value=" site:EC">Ecuador</option>
    <option value=" site:EG">Egypt</option>
    <option value=" site:SV">El Salvador</option>
    <option value=" site:ER">Eritrea</option>
    <option value=" site:EE">Estonia</option>
    <option value=" site:ET">Ethiopia</option>
    <option value=" site:FK">Falkland Islands</option>
    <option value=" site:FO">Faroe Islands</option>
    <option value=" site:FJ">Fiji</option>
    <option value=" site:FI">Finland</option>
    <option value=" site:FR">France</option>
    <option value=" site:GF">French Guiana</option>
    <option value=" site:PF">French Polynesia</option>
    <option value=" site:GA">Gabon</option>
    <option value=" site:GM">Gambia</option>
    <option value=" site:GE">Georgia</option>
    <option value=" site:DE">Germany</option>
    <option value=" site:GI">Gibraltar</option>
    <option value=" site:GR">Greece</option>
    <option value=" site:GL">Greenland</option>
    <option value=" site:GD">Grenada</option>
    <option value=" site:GP">Guadeloupe</option>
    <option value=" site:GT">Guatemala</option>
    <option value=" site:GN">Guinea</option>
    <option value=" site:GW">Guinea-Bissau</option>
    <option value=" site:GY">Guyana</option>
    <option value=" site:HN">Honduras</option>
    <option value=" site:HK">Hong Kong SAR China</option>
    <option value=" site:HU">Hungary</option>
    <option value=" site:IS">Iceland</option>
    <option value=" site:IN">India</option>
    <option value=" site:IE">Ireland</option>
    <option value=" site:IL">Israel</option>
    <option value=" site:IT">Italy</option>
    <option value=" site:JM">Jamaica</option>
    <option value=" site:JP">Japan</option>
    <option value=" site:JO">Jordan</option>
    <option value=" site:KZ">Kazakhstan</option>
    <option value=" site:KE">Kenya</option>
    <option value=" site:KI">Kiribati</option>
    <option value=" site:KW">Kuwait</option>
    <option value=" site:KG">Kyrgyzstan</option>
    <option value=" site:LA">Laos</option>
    <option value=" site:LV">Latvia</option>
    <option value=" site:LS">Lesotho</option>
    <option value=" site:LI">Liechtenstein</option>
    <option value=" site:LT">Lithuania</option>
    <option value=" site:LU">Luxembourg</option>
    <option value=" site:MK">Macedonia</option>
    <option value=" site:MG">Madagascar</option>
    <option value=" site:MW">Malawi</option>
    <option value=" site:MY">Malaysia</option>
    <option value=" site:MV">Maldives</option>
    <option value=" site:ML">Mali</option>
    <option value=" site:MT">Malta</option>
    <option value=" site:MH">Marshall Islands</option>
    <option value=" site:MQ">Martinique</option>
    <option value=" site:MR">Mauritania</option>
    <option value=" site:MU">Mauritius</option>
    <option value=" site:YT">Mayotte</option>
    <option value=" site:MX">Mexico</option>
    <option value=" site:FM">Micronesia</option>
    <option value=" site:MD">Moldova</option>
    <option value=" site:MC">Monaco</option>
    <option value=" site:MN">Mongolia</option>
    <option value=" site:ME">Montenegro</option>
    <option value=" site:MS">Montserrat</option>
    <option value=" site:MA">Morocco</option>
    <option value=" site:MZ">Mozambique</option>
    <option value=" site:NA">amibia</option>
    <option value=" site:NR">Nauru</option>
    <option value=" site:NP">epal</option>
    <option value=" site:NL">Netherlands</option>
    <option value=" site:AN">Netherlands Antilles</option>
    <option value=" site:NC">ew Caledonia</option>
    <option value=" site:NZ">New Zealand</option>
    <option value=" site:NI">Nicaragua</option>
    <option value=" site:NE">Niger</option>
    <option value=" site:NG">Nigeria</option>
    <option value=" site:NU">Niue</option>
    <option value=" site:NF">Norfolk Island</option>
    <option value=" site:NO">Norway</option>
    <option value=" site:OM">Oman</option>
    <option value=" site:PW">alau</option>
    <option value=" site:PA">Panama</option>
    <option value=" site:PG">Papua New Guinea</option>
    <option value=" site:PY">Paraguay</option>
    <option value=" site:PE">Peru</option>
    <option value=" site:PH">Philippines</option>
    <option value=" site:PN">Pitcairn Islands</option>
    <option value=" site:PL">Poland</option>
    <option value=" site:PT">Portugal</option>
    <option value=" site:QA">Qatar</option>
    <option value=" site:RE">éunion</option>
    <option value=" site:RO">Romania</option>
    <option value=" site:RU">Russia</option>
    <option value=" site:RW">Rwanda</option>
    <option value=" site:WS">Samoa</option>
    <option value=" site:SM">San Marino</option>
    <option value=" site:ST">ão Tomé & Príncipe</option>
    <option value=" site:SA">Saudi Arabia</option>
    <option value=" site:SN">Senegal</option>
    <option value=" site:RS">Serbia</option>
    <option value=" site:SC">Seychelles</option>
    <option value=" site:SL">Sierra Leone</option>
    <option value=" site:SG">Singapore</option>
    <option value=" site:SK">Slovakia</option>
    <option value=" site:SI">Slovenia</option>
    <option value=" site:SB">Solomon Islands</option>
    <option value=" site:SO">Somalia</option>
    <option value=" site:ZA">South Africa</option>
    <option value=" site:KR">South Korea</option>
    <option value=" site:ES">Spain</option>
    <option value=" site:LK">Sri Lanka</option>
    <option value=" site:SH">St. Helena</option>
    <option value=" site:KN">St. Kitts & Nevis</option>
    <option value=" site:LC">St. Lucia</option>
    <option value=" site:PM">St. Pierre & Miquelon</option>
    <option value=" site:VC">St. Vincent & Grenadines</option>
    <option value=" site:SR">Suriname</option>
    <option value=" site:SJ">Svalbard & Jan Mayen</option>
    <option value=" site:SZ">Swaziland</option>
    <option value=" site:SE">Sweden</option>
    <option value=" site:CH">Switzerland</option>
    <option value=" site:TW">Taiwan</option>
    <option value=" site:TJ">Tajikistan</option>
    <option value=" site:TZ">Tanzania</option>
    <option value=" site:TH">Thailand</option>
    <option value=" site:TG">Togo</option>
    <option value=" site:TO">Tonga</option>
    <option value=" site:TT">Trinidad & Tobago</option>
    <option value=" site:TN">Tunisia</option>
    <option value=" site:TR">Turkey</option>
    <option value=" site:TM">Turkmenistan</option>
    <option value=" site:TC">Turks & Caicos Islands</option>
    <option value=" site:TV">Tuvalu</option>
    <option value=" site:UG">Uganda</option>
    <option value=" site:UA">Ukraine</option>
    <option value=" site:AE">United Arab Emirates</option>
    <option value=" site:GB">United Kingdom</option>
    <option value=" site:US">United States</option>
    <option value=" site:UY">Uruguay</option>
    <option value=" site:VU">Vanuatu</option>
    <option value=" site:VA">Vatican City</option>
    <option value=" site:VE">Venezuela</option>
    <option value=" site:VN">Vietnam</option>
    <option value=" site:WF">Wallis & Futuna</option>
    <option value=" site:YE">Yemen</option>
    <option value=" site:ZM">Zambia</option>
    <option value=" site:ZW">Zimbabwe</option>
</select>

  &nbsp;&nbsp;<br><br><center><input href="#" onclick="document.forms[0].submit();return false;" type="submit" class="btn btn-success" value="Submit" id="button"/></center>
 </form>
<font color='black'>
<pre>
<?php
error_reporting(0);
set_time_limit(0);
if($_POST['dork']){
$negara = $_POST['country'];
$no=1;
$total_target =0;
for ($i=0; $i <$no; $i++) {
$kunAPI = "AIzaSyDYG1FME1N7meBZLcywY7VojMHmtUAUIzY";
$dork = urlencode($_POST['dork'].$negara);
$result = file_get_contents("http://ajax.googleapis.com/ajax/services/search/web?v=1.0&hl=iw&rsz=8&q={$dork}&key=$kunAPI&start={$i}");
$data = json_decode($result, true);
if($data['responseStatus']=="200"){
foreach ($data['responseData']['results'] as $key) {
       
 
 
        echo '<a href="'.$key['unescapedUrl'].'" target="_Blank"><font face="Tahoma" size="2" color="#f16e50">'.$key['unescapedUrl'].'</font></a><br>';
       
    $total_target++;
    ob_flush();
    flush();
    sleep(1);
}
$no++;
}else if($data['responseStatus']=="403"){
echo "STOP Because, Suspected Terms of Service Abuse!!!<br>";
}else if($data['responseStatus']=="400"){
echo "Tidak ada hasil - Scan Done !!!<br>";
}
 
        ob_flush();
    flush();
    sleep(1);
}
echo '<br><br><font face="Tahoma" size="2" color="#f16e50">Dork : '.urldecode($dork).' | Total Target : '.$total_target.'</font><br>';
}
?>
</pre>
</font>
</body>
</html>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>