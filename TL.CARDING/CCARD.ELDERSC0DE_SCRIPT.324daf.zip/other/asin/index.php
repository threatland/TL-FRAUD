<?php
include('../../head.php');
?>
<?php
if ($_GET['Submit'] == 'Submit') {
    $pages = $_REQUEST["p"];
    $all_asin = "";
    ini_set('max_execution_time', '0');
    ini_set('max_input_time', '0');
    ini_set('memory_limit', '128M');
    #ini_set('error_reporting','~E_ALL');
    function get_page($url) {
        $ch = curl_init();
        $timeout = 0; // set to zero for no timeout
        $useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
        curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $String = curl_exec($ch);
        curl_close($ch);
        return $String;
    }
    if (!$_REQUEST["url"]) {
        exit();
    }
    $csv_info = "";
    $csv_comma = "";
    $csv_tab = "";
    ////////////////////////////////////////////////////////////////
    $url = $_REQUEST["url"];
    ////////////////////////////////////////////////////////////////
    $rankno = 1;
    for ($i = 1;$i <= $pages;$i++) {
        $urlx = $url . "&page=$i";
        $page = get_page($urlx);
        //echo $page."-";
        if (strpos($page, "did not match") > 0) {
            $i = $pages + 1;
            break;
        }
        $page = substr($page, strpos($page, "<h1 id=\"breadCrumb\">"));
        $page = substr($page, 0, strpos($page, "<div id=\"centerBelowExtra\">"));
        $aStr = explode('id="result_', $page);
        $first = 0;
        foreach ($aStr as $nn => $item) {
            $item = str_replace("
", "", $item);
            $item = str_replace("
", "", $item);
            $item = str_replace("<div", "
<div", $item);
            $item = str_replace("</div>", "</div>
", $item);
            if ($first == 0) {
                $first++;
                continue;
            }
            preg_match('/name="(.*)"/', $item, $match);
            $asin = trim($match[1]);
            $match[1] = "";
            preg_match('/<br clear="all" \/>(.*)<\/a><\/div>/', $item, $match);
            $proddesc = trim($match[1]);
            $match[1] = "";
            if ($proddesc == "") {
                preg_match('/<div class="result firstRow product specific">(.*)<\/div>/', $item, $match);
                $proddesc = trim(strip_tags($match[1]));
                $match[1] = "";
            }
            $proddesc = html_entity_decode($proddesc);
            if ($asin != "") {
                $all_asin.= "$asin$proddesc
";
            }
            flush();
            $rankno++;
        }
        echo "$i ";
        flush();
        if (strpos($page, "<span class=\"pagnDisabled\">Next") > 0) {
            $i = $pages + 1;
            break;
        }
    }
    echo "<br><center><b>ASIN List</b></center><br />
";
    echo "<textarea name=\"asin\" rows=\"20\" cols=\"100\" style=\"margin: 0px 0px 10px; width: 810px; height: 725px;\">
";
    echo $all_asin;
    echo "</textarea>
";
} else {
    php
?>
<title>Amazon Asin Generator</title>
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Amazon Asin Generator</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<form name="form1" method="GET" action="" style="padding:5px;">
<p>
<center><input name="url" type="text" placeholder="http://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=drone" cols="30" rows="10" style="margin: 0px; height: 20px; width: 607px;">
  <br />
<br/>Number of page: <input name="p" value = "10" type="text"  cols="30" rows="10" style="margin: 0px; height: 20px; width: 30px;" /></p></center>
<p>
  <center><input class="btn btn-success" type="submit" name="Submit" value="Submit" />   <input class="btn btn-danger" type="reset" name="reset" value="Reset" /></center>
  
</p>
</form>



<?php
}
php
?>