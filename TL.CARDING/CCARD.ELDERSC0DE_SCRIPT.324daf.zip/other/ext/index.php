<?php 
include('../../head.php');
?>
        <title>Mail Extractor</title>
<link rel="shortcut icon" type="/favicon.ico" href=../favicon.ico>
<title>Mail Extractor</title>
<script language="javascript">
<!--

var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}

document.oncontextmenu=new Function("return false")
// --> 
</script>
<script language="JavaScript" type="text/javascript">
mensaje = '*<--Blackshadow-->*';font = 'OCR A Extended';size = 2.5;color = '#00FF00';velocidad = 0.6;
n4 = (document.layers);ie = (document.all);n6 = (document.getElementById);
mensaje = mensaje.split(');n = mensaje.length;
a = size*10;ymouse = 0;xmouse = 0;props = "<font face="+font+" color="+color+" size="+size+">";
if (n4){for ( i = 0; i < n; i++)document.write('<layer left="0" top="0" width="+a+" name="n4mensaje'+i+'" height="+a+"><center>
'+props+mensaje[i]+'</font></center>
</layer>');}else if (ie){document.write('<div id="padre" style="position:absolute;top:0px;left:0px">
<div style="position:relative">
');for (i=0; i < n; i++)document.write('<div id="iemensaje" style="position:absolute;top:0px;left:0;height:'+a+';width:'+a+';text-align:center">'+props+mensaje[i]+'</font></div>
');document.write('</div>
</div>
');}else if (n6){document.write('<div id="padre" style="position:absolute;top:0px;left:0px">
<div style="position:relative">
');for (i = 0; i < n; i++)document.write('<div id="iemensaje'+i+'" style="position:absolute;top:0px;left:0;height:'+a+';width:'+a+';text-align:center">'+props+mensaje[i]+'</font></div>
');document.write('</div>
</div>
');}
if(n4)window.captureEvents(Event.MOUSEMOVE);
function Mouse(evento){ if(ie){xmouse = event.x+20;ymouse = event.y+20;}else if(n4 || n6){xmouse = evento.pageX+20;ymouse = evento.pageY+20;}}
if(n4)window.onMouseMove = Mouseelse if(ie || n6)document.onmousemove = Mouse;
y = new Array();x = new Array();Y = new Array();X = new Array();Yaux = new Array();Xaux = new Array();
for (i=0; i < n; i++){y[i] = 0;x[i] = 0;Y[i] = 0;X[i] = 0;Yaux[i] = 0;Xaux[i] = 0;}
function asigna(){if (ie)padre.style.top = document.body.scrollTop;
for (i = 0; i < n; i++){if(n4){document.layers['n4mensaje'+i].top = y[i];document.layers['n4mensaje'+i].left = x[i]+(i*(a/2));}else if(ie){iemensaje[i].style.top = y[i];iemensaje[i].style.left = x[i]+(i*(a/2));}else if(n6){eval("document.getElementById('iemensaje"+i+"').style.top = '"+y[i]+"px'");eval("document.getElementById('iemensaje"+i+"').style.left = '"+(x[i]+(i*(a/2)))+"px'");} }}
function ondula(){y[0]=Math.round(Y[0] +=((ymouse)-Y[0])*velocidad);x[0]=Math.round(X[0] +=((xmouse)-X[0])*velocidad);
for (var i = 1; i < n; i++){Yaux[i] = Math.round(Y[i]);Xaux[i ]= Math.round(X[i]);y[i] = Math.round(Y[i]=Yaux[i]+(y[i-1]-Y[i])*velocidad);x[i] = Math.round(X[i]=Xaux[i]+(x[i-1]-X[i])*velocidad);}asigna();setTimeout('ondula()',50);}
window.onload = ondula;
</script>
<script type="text/javascript">
function selectText(containerid) {
    if (document.selection) {
        var range = document.body.createTextRange();
        range.moveToElementText(document.getElementById(containerid));
        range.select();
    } else if (window.getSelection()) {
        var range = document.createRange();
        range.selectNode(document.getElementById(containerid));
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
    }
}
</script>
<script type="text/javascript">
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="?ref=true"});
//]]>
</script>
<SCRIPT LANGUAGE="JAVASCRIPT" TYPE="text/javascript">


<!-- Begin

function copy() {
textRange = document.extractor.output.createTextRange();
textRange.execCommand("RemoveFormat");
textRange.execCommand("Copy");
}

function paste() {
textRange = document.extractor.input.createTextRange();
textRange.execCommand("RemoveFormat");
textRange.execCommand("Paste");
}

function help(){

var imgwid = 450;
var imghgt = 360;


content += ('</head><body onload="window.focus();">');
content += ('<B>Quick and dirty</B>');
content += ('<OL>');
content += ('<LI>Copy all text from any webpages, documents, files, etc...');
content += ('<LI>Paste it into <B>Input Window</B>.');
content += ('<LI>Click "<I>Extract</I>" button.');
content += ('<LI>Copy the result from <B>Output Window</B> to somewhere and save it.');
content += ('<LI>Click "<I>Reset</I>" button to start all over again.');
content += ('</OL>');
content += ('<P><B>More Controls</B>');
content += ('<OL>');
content += ('<LI>Click "<I>Paste Input</I>" link to paste any text you copied elsewhere into <B>Input Window</B>.');
content += ('<LI>Click "<I>Copy Output</I>" link to copy whatever text inside <B>Output Window</B>.');
content += ('<LI>Choose different separator from the dropdown menu or specify your own. Default is comma.');
content += ('<LI>You can group a number of emails together. Each group is separated by a new line. Please enter number only.');
content += ('<LI>Check "<I>Sort Alphabetically</I>" checkbox to arrange extracted emails well... alphabetically.');
content += ('<LI>You can extract or exclude emails containing certain string (text). Useful if you only want to get email from a particular domain.');
content += ('<LI>You can choose to extract web addresses instead of email addresses.');
content += ('</OL>');
content += ('<DIV ALIGN="CENTER"><INPUT TYPE="button" VALUE="Close" onClick="javascript:window.close();"></DIV>');
content += ('</body></html>');

var winl = (screen.width - imgwid) / 2;
var wint = (screen.height - imghgt) / 2;
helpwindow = window.open('','help','width=' + imgwid + ',height=' + imghgt + ',resizable=0,scrollbars=0,top=' + wint + ',left=' + winl + ',toolbar=0,location=0,directories=0,status=0,menubar=0,copyhistory=0');
helpwindow.document.write(content);
helpwindow.document.close();
}

function checksep(value){
if (value) document.extractor.sep.value = "other";
}

function numonly(value){
if (isNaN(value)) {
	window.alert("Please enter a number or else \nleave blank for no grouping.");
	document.extractor.groupby.focus();
}
}

function findEmail() {
var email = "No EMaill?? please input emaill..!! example => email@domain.com";
var a = 0;
var ingroup = 0;
var separator = document.extractor.sep.value;
var string = document.extractor.string.value;
var groupby = Math.round(document.extractor.groupby.value);
var address_type = document.extractor.address_type.value;
var input = document.extractor.input.value;

if (document.extractor.lowcase.checked) {
	var input = input.toLowerCase();
}

if (separator == "new") separator = "\n";
if (separator == "other") separator = document.extractor.othersep.value;


if (address_type == "email") {
	rawemail = input.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
}

var norepeat = new Array();
var filtermail = new Array();
if (rawemail) {
	if (string){
		x = 0;
		for (var y=0; y<rawemail.length; y++) {
			if (document.extractor.filter_type.value == 1) {
				if (rawemail[y].search(string) >= 0) {
					filtermail[x] = rawemail[y];
					x++;
				}
			} else {
				if (rawemail[y].search(string) < 0) {
					filtermail[x] = rawemail[y];
					x++;
				}
			}
		}
		rawemail = filtermail;
	}

	for (var i=0; i<rawemail.length; i++) {
		var repeat = 0;
		
		// Check for repeated emails routine
		for (var j=i+1; j<rawemail.length; j++) {
			if (rawemail[i] == rawemail[j]) {
				repeat++;
			}
		}
		
		// Create new array for non-repeated emails
		if (repeat == 0) {
			norepeat[a] = rawemail[i];
			a++;
		}
	}
	if (document.extractor.sort.checked) norepeat = norepeat.sort(); // Sort the array
	email = "";
	// Join emails together with separator
	for (var k = 0; k < norepeat.length; k++) {
		if (ingroup != 0) email += separator;
		email += norepeat[k];
		ingroup++;
		
		// Group emails if a number is specified in form. Each group will be separate by new line.
		if (groupby) {
			if (ingroup == groupby) {
				email += '\n\n';
				ingroup = 0;
			}
		}
	}
}

// Return array length
var count = norepeat.length;

// Print results
document.extractor.count.value = count;
document.extractor.output.value = email;
}
//  End -->
</SCRIPT>
<center><script language="JavaScript1.2">
/Flashing Neon /
var neonbasecolor="grey"
var neontextcolor="red"
var neontextcolor2="lime"
var neontexsize="5"
var flashspeed=50	
var flashingletters=2	
var flashingletters2=15	
var flashpause=0	
///No need to edit below this line/////
var n=0
if (document.all||document.getElementById){
document.write('<b>')
document.write('<font color="'+neonbasecolor+neontexsize+'">')
for (m=0;m<message.length;m++)
document.write('<span id="neonlight'+m+'">'+message.charAt(m)+'</span>')
document.write('</font>')
document.write('</b>')
}
else
document.write(message)
function crossref(number){
var crossobj=document.all? eval("document.all.neonlight"+number) : document.getElementById("neonlight"+number)
return crossobj
}
function neon(){
//Change all letters to base color
if (n==0){
for (m=0;m<message.length;m++)
crossref(m).style.color=neonbasecolor
}
//cycle through and change individual letters to neon color
crossref(n).style.color=neontextcolor
if (n>flashingletters-1) crossref(n-flashingletters).style.color=neontextcolor2
if (n>(flashingletters+flashingletters2)-1) crossref(n-flashingletters-flashingletters2).style.color=neonbasecolor
if (n<message.length-1)
n++
else{
n=0
clearInterval(flashing)
setTimeout("beginneon()",flashpause)
return
}
}
function beginneon(){
if (document.all||document.getElementById)
flashing=setInterval("neon()",flashspeed)
}
beginneon()
</script></center>


</HEAD>
<BODY>
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Email Extractor</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<DIV ALIGN="CENTER">
<FORM NAME="extractor">
<TABLE CLASS="bordercolor" CELLPADDING=1 CELLSPACING=0 BORDER=0><TR><TD>
<TABLE CLASS="maincolor" CELLPADDING=4 CELLSPACING=0 BORDER=0>
<TR CLASS="titlebarcolor" VALIGN="MIDDLE"> 
<TD ALIGN="RIGHT" NOWRAP></TD>
</TR>
<TR>
<TD VALIGN="TOP" ALIGN="CENTER" WIDTH="50%">
<B>Input Window</B><BR>
<TEXTAREA NAME="input" class="coode" placeholder="inputemail@domain.com" rows=10 cols=80></TEXTAREA>
</TD>
<TD VALIGN="TOP" ALIGN="CENTER" WIDTH="50%">
<B>Output Window</B><BR>
<TEXTAREA NAME="output" class="coode" placeholder="outputemail@domain.com" rows=10 cols=80></TEXTAREA>
</TD></TR>
<TR>
<TD VALIGN="TOP" ALIGN="CENTER">

<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
<!--
if ((navigator.appName=="Microsoft Internet Explorer")&&(parseInt(navigator.appVersion)>=4)) document.write('<A HREF="#" onClick="paste();">Paste Input</A>');
else document.write('Paste Input');
// -->
</SCRIPT>

</TD>
<TD VALIGN="TOP" ALIGN="CENTER">

<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
<!--
if ((navigator.appName=="Microsoft Internet Explorer")&&(parseInt(navigator.appVersion)>=4)) document.write('<A HREF="#" onClick="copy();">Copy Output</A>');
else document.write('Copy Output');
// -->
</SCRIPT>

</TD></TR>
<TR>
<TD VALIGN="TOP" ALIGN="LEFT" COLSPAN=2>
<fieldset title="Output Option">
<legend align="left"><B>Output Option</B></legend>
<BR>
Separator:
<SELECT NAME="sep">
<OPTION VALUE="new" SELECTED>New Line</OPTION>
<OPTION VALUE="|">Pipe</OPTION>
<OPTION VALUE=" : ">Colon</OPTION>
<OPTION VALUE=", ">Comma</OPTION>
<OPTION VALUE="other">Other</OPTION>
</SELECT>
<INPUT TYPE="TEXT" NAME="othersep" SIZE=3 onBlur="checksep(this.value);">
&nbsp;&nbsp;
Group: <INPUT TYPE="TEXT" SIZE=3 NAME="groupby" onBlur="numonly(this.value);"> Addresses
&nbsp;&nbsp;
<LABEL FOR="sortbox"><INPUT TYPE="CHECKBOX" NAME="sort" id="sortbox">Sort Alphabetically</LABEL>
&nbsp;&nbsp;
<LABEL FOR="casebox"><INPUT TYPE="CHECKBOX" NAME="lowcase" id="casebox" CHECKED>To Lowercase?</LABEL>
</fieldset>
<BR>
<fieldset title="Filter Option">
<legend align="left"><B>Filter Option</B></legend>
<BR>
<SELECT NAME="filter_type">
<OPTION VALUE=1 SELECTED>Only</OPTION>
<OPTION VALUE=0>Do not</OPTION>
</SELECT>
extract address containing this string: <INPUT TYPE="TEXT" class="coode" SIZE=20 NAME="string">
<BR>
<BR>
Type of address to extract: 
<SELECT NAME="address_type">
<OPTION VALUE="email" SELECTED>Email</OPTION>
</SELECT>
</fieldset>
</TD></TR>
<center><TR>
<TD VALIGN="TOP" ALIGN="center">
<INPUT CLASS="btn btn-success" TYPE="BUTTON" CLASS="button" VALUE="Extract" onClick="findEmail();"> &nbsp;
<INPUT TYPE="RESET" CLASS="btn btn-danger" VALUE="Reset">&nbsp;&nbsp;&nbsp;
</TD></center>
<TD VALIGN="TOP" ALIGN="RIGHT" NOWRAP>
Counter: <INPUT NAME="count" class="coode" SIZE=5 READONLY>
</TD></TR>
</TABLE>
</TD></TR></TABLE>
</FORM>
</DIV>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
 </div>
        <!--/.fluid-container-->
        <script src="/vendors/jquery-1.9.1.min.js"></script>
        <script src="/bootstrap/js/bootstrap.min.js"></script>
        <script src="/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="/assets/scripts.js"></script>
        <script>
</BODY>
</HTML>