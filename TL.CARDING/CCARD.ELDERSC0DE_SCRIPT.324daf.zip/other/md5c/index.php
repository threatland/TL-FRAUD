<?php 
include('../../head.php');
?>
        <title>MD5 Encryption</title>
                <link href='/favicon.ico' rel='icon' type='image/ico' />
                <div class="container">
                        <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-offset-3">
                                        <div class="box">
                                                <div class="info" >
                                                        <form method="POST">                
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>MD5 Encryption</b></center></div>
                                </div>
                                <div class="block-content collapse in">
                               <center><textarea name="mytext" cols="30" rows="10" style="margin: 0px; height: 212px; width: 419px;"><?php if(isset($_POST['mytext'])) { echo htmlentities($_POST['mytext']); } ?></textarea></center>
                                                                <br/><center><button type="submit" class="btn btn-success">Submit</button></center><br><center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
                                                                <?php
                                                                        if(isset($_POST['mytext'])) {
                                                                                echo('<hr/><div class="well">Result: ' . md5($_POST['mytext']) . "</div>");
                                                                        }
                                                                ?>
                                                                </div>
                                                        </form>
                                                </div><hr/>
                                              
                                </div>
                        </div>
                </div>

                <script src="js/jquery.js"></script>
                <script src="js/bootstrap.min.js"></script>
        </body>
</html>