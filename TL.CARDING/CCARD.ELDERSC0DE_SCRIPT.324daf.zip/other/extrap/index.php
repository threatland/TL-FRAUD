<?php 
include('../../head.php');
?>
<html>
<title>Credit Card Extrap</title>                     
<script>

function trimSpaces(s){
        var res;
        var i;
        res = "";
        for (i = 0; i < s.length; i++){
                if ((s.charAt(i) != " ") && (s.charAt(i) != "-"))
                        res += s.charAt(i);
        }
        return res;
}

function isValidInput(s){
        for (i = 0; i < s.length; i++){
                var i;
                if ((s.charAt(i) < "0") || (s.charAt(i) > "9"))
                        return false;
        }
        return true;
}


function fix(num){
        if (num <= 9) return num; else return (num - 9);
}

function check(number){
        var i;
        var ganjil;
        var genap;
        var tanda;

        genap = 0;
        ganjil = 0;
        //tanda = 1 artinya jumlah digitnya ganjil
        if (number.length % 2) tanda = 0; else tanda = 1;
        for (i = 0; i < number.length; i++) {
                if ((i + tanda) % 2) //ganjil
                        ganjil += fix(2 * (number.charAt(i)));
                else
                        genap += parseInt(number.charAt(i), 10);
        }
        return (((ganjil + genap) % 10) == 0);
}


function validateInput(inp){
        var tmp;
        var Msg;
        var Msg2;
        tmp = trimSpaces(inp.nomor.value)
        if ((tmp == "") || (!isValidInput(tmp))){
                alert("Nomor Kartu yang Anda masukkan Salah !!");
                return false;
        }
        Msg = "Kartu ini ";
        Msg2 = "";
        if (check(tmp))
                alert(Msg + "\n\nVALID!!\n\n" + Msg2);
        else
                alert(Msg + "\n\nTIDAK VALID!!\nCek lagi Nomor Kartunya.\n\n" + Msg2);
        return false;
}

//mencari beberapa angka valid yang dekat dengan nomor yang diberikan
function findN(formName){
        var start;
        var startn;
        var res;
        var i;
		var exp;
		var cvv;
		var delim;

        expH = trimSpaces(formName.exp.value);
        cvvH = trimSpaces(formName.cvv.value);
        delimH = trimSpaces(formName.delim.value);
        start = trimSpaces(formName.nomor.value);
        if ((start == "") || (!isValidInput(start))){
                alert("Check Form Please!!");
                return;
        }
        res = "";
        startn = parseInt(start,10);
        for (i=-50; i<79000; i++)  {
                num = "" + (parseInt(start,10)+i);
                if (check(num)) {
                        res += (startn + i) + delimH + expH + delimH + cvvH + "\n";
                }
        }
        formName.hasil.value = res;
}

			
</script><b>
<body>

                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Credit Card Extrap</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<center>
<form name="InpForm" onSubmit="return validateInput(this);">
<input type="TEXT" name="nomor" placeholder="434256499589xxxx">
<input type="TEXT" name="exp" placeholder="0115">
<input type="TEXT" name="cvv" placeholder="123">
<input type="TEXT" name="delim" value="|" size="1"><br>
<input class="btn btn-success" type="BUTTON" name="buat" onClick="findN(InpForm)" VALUE="Submit"><br><br></div>
<p><center><textarea name="hasil" cols="60" rows="10" style="margin: 0px 0px 10px; width: 312px; height: 254px;"></textarea>
<div id="jumlah" style="display: none;"></div><br></form></center>
</br>
</td>
</body></html>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>