<?php 
include('../../head.php');
?>
<title>Access Token Generator</title>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Access Token Generator</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<center>
<textarea name="data" id="data" color="transparent" cols="5" rows="10" style="width: 477px; margin: 0px 0px 5px; height: 164px;" >
<?php

function bacaHTML($url){
     // inisialisasi CURL
     $data = curl_init();
     // setting CURL
     curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($data, CURLOPT_URL, $url);
     // menjalankan CURL untuk membaca isi file
     $hasil = curl_exec($data);
     curl_close($data);
     return $hasil;
}
echo bacaHTML('http://akatsuki-id.club/token.php');

?>
</textarea></center><center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
</body>
</html>