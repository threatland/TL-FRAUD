<?php
include('../head.php');
?>
                        	<div class="navbar">
        <title>Card Checker - Akatsuki-ID</title>


                    <div class="row-fluid">
		                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Card Checker</b></center></div>
                                </div>

                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Status</th>
                                                <th>About</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><i class="icon-ok"></i></td>
                                                <td><b><a href="ccn1">CCN Gate 1</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td><i class="icon-remove"></i></td>
                                                <td><b><a href="#">CCN Gate 2</a></b></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td><i class="icon-remove"></i></td>
                                                <td><b><a href="#">CCN Gate 3</a></b></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            
        </div>
        <!--/.fluid-container-->
        <script src="vendors/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="assets/scripts.js"></script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>
    </body>

</html>