<?php
session_start();
error_reporting(0); 

$ccnum1 = $_POST['cclist'].'|';
$ccnum1 = str_replace("Live","",$ccnum1);
$ccnum1 = str_replace("LIVE","",$ccnum1);
if ($ccnum1 == 0) {
header('location: /');
break;
}
$ccnum1 = str_replace(" ","",$ccnum1);
$potong = str_replace("|","",$ccnum1);
$jumlah = strlen($potong);
$cc = substr($potong, 0, 1);
if ($cc == 4) {
if ($jumlah > 24) {
$num = substr($potong, 0, 16);
$expm = substr($potong, 16, 2);
$expy = substr($potong, 18, 4);
$cvv = substr($potong,22);
}
if ($jumlah < 24) {
$num = substr($potong, 0, 16);
$expm = substr($potong, 16, 2);
$expy = '20'.substr($potong, 18, 2);
$cvv = substr($potong,20);
}
}
if ($cc == 5) {
if ($jumlah > 24) {
$num = substr($potong, 0, 16);
$expm = substr($potong, 16, 2);
$expy = substr($potong, 18, 4);
$cvv = substr($potong,22);
}
if ($jumlah < 24) {
$num = substr($potong, 0, 16);
$expm = substr($potong, 16, 2);
$expy = '20'.substr($potong, 18, 2);
$cvv = substr($potong,20);
}
}
if ($cc == 3) {
if ($jumlah > 24) {
$num = substr($potong, 0, 15);
$expm = substr($potong, 15, 2);
$expy = substr($potong, 17, 4);
$cvv = substr($potong, 21);
}
if ($jumlah < 24) {
$num = substr($potong, 0, 15);
$expm = substr($potong, 15, 2);
$expy = '20'.substr($potong, 17, 2);
$cvv = substr($potong, 19);
}
}
if($cc == 6){
echo '{"error":-1,"msg":"<font color=purple><b>Unknown</b></font> | '.$ccnum1.' ./Akatsuki-ID"}';
break;
}
$charge=rand(1,9);
$charge1=rand(01,99);

$cst = mysql_query("SELECT * FROM api WHERE status='1'");
while($cstapi = mysql_fetch_assoc($cst)){
$api = $cstapi['api'];
}
$charge = rand(2.0,6.0);
$bin = str_replace(' ', '', $num);
$bin     = substr($bin, 0, 6);
$getbank = explode($bin, file_get_contents("http://bins.pro/search?action=searchbins&bins=" . $bin . "&bank=&country="));
$jeniscc = explode("</td><td>", $getbank[2]);
$namabnk = explode("</td></tr>", $jeniscc[5]);
$ccbrand = $jeniscc[2];
$ccbank  = $namabnk[0];
$cctype  = $jeniscc[3];
$ccklas  = $jeniscc[4];
$format = $num.'|'.$expm.'|'.$expy.'|'.$cvv;



$b = rand(0,7);
$cre='[CRE:'.$credit.']';
$keredit=$credit-3;
if ($b == 1) {
mysql_query("UPDATE `user` SET `credits`=credits-3 WHERE email='$email'");
echo '{"error":0,"msg":"<font color=green><b>Live</b></font> | '.$ccnum1.' [BIN: <font color=blue><b>' . $ccbrand . '</b></font><font color=red><b> - </b></font><font color=blue><b>' . $ccbank . '</b></font><font color=red><b> - </b></font><font color=blue><b>' . $cctype . '</b></font><font color=red><b> - </b></font><font color=blue><b>' . $ccklas . '</b></font>][GATE:01] ./Akatsuki-ID"}';
break;
} if ($b == 2) {
echo '{"error":2,"msg":"<font color=red><b>Die</b></font> | '.$ccnum1.' [GATE:01] ./Akatsuki-ID"}';
break;
} if ($b == 3) {
echo '{"error":-1,"msg":"<font color=purple><b>Unknown</b></font> | '.$format.' | [GATE:01] ./Akatsuki-ID"}';
break;
}
if ($b == 4) {
mysql_query("UPDATE `api` SET `status`='3' WHERE api='$api'");
echo '{"error":2,"msg":"<font color=red><b>Die</b></font> | '.$ccnum1.' [GATE:01] ./Akatsuki-ID"}';
break;
}
if ($b == 5) {
echo '{"error":-1,"msg":"<font color=purple><b>Unknown</b></font> | '.$format.' | [GATE:01] ./Akatsuki-ID"}';
break;
}
mysql_query("UPDATE `api` SET `status`='3' WHERE api='$api'");
echo '{"error":2,"msg":"<font color=red><b>Die</b></font> | '.$ccnum1.' [GATE:01] ./Akatsuki-ID"}';
break;
?>
