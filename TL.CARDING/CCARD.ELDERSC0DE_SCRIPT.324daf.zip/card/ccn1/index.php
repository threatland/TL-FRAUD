<?php
include('../../head.php');
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="robots" content="noindex"/>
<!--[if IE]>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<![endif]-->
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/js/jquery.min.js"></script>
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/js/jquery.gritter.min.js"></script>
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/js/eakroko.min.js"></script>
<script type="text/javascript" src="/card/ccn1/akatsuki/alien07/checkers.js"></script>
<link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
<link rel="shortcut icon" href="/favicon.ico"/>
<title>CCN Gate 1</title>

        <link href="/assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
</head>


</div>
<div class="panel-body">
<form action="" method="post" class='form-vertical'>
<div class="col-lg-6">
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>CCN Gate 1</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<textarea name="mailpass" id="mailpass" class="input-block-level" rows="10" placeholder="53012724539xxxxx|05|14|653"></textarea>
<div class="col-lg-4">
<center>
<button class="btn btn-success" id="submit">Submit</button>
<button class="btn btn-danger" id="stop">Stop</button><br><br><span id="checkStatus"> </span></center>
</form>
</div>
</div>
</div>
<div id="result">
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Live </b></font><span class="badge badge-success" class="pull-right" id="tvmit_live_count">0</span>
</div>
                                </div>
                                <div class="block-content collapse in">
<div id="tvmit_live">
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> DIE </b></font><span class="badge badge-important" class="pull-right" id="tvmit_die_count">0</span></div>
                                </div>
                                <div class="block-content collapse in">
        <div id="tvmit_die">
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Wrong Format </b></font><span class="badge badge-info" class="pull-right" id="tvmit_wrong_count">0</span></div>
                                </div>
                                <div class="block-content collapse in">
        <div id="wrong"></div>
</div>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                                </div>
                            </div>

<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
        <!--/.fluid-container-->
        <script src="/vendors/jquery-1.9.1.min.js"></script>
        <script src="/bootstrap/js/bootstrap.min.js"></script>
        <script src="/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="/assets/scripts.js"></script>
        <script>
<?php 
include('../../card/ccn1/bawah.php'); 
?>