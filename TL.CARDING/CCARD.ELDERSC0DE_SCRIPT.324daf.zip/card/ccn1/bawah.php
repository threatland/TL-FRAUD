
<script type="text/javascript" src="/assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
<script type="text/javascript" src="/assets/plugins/flot/jquery.flot.js"></script>
<script type="text/javascript" src="/assets/plugins/flot/jquery.flot.resize.js"></script>
<script type="text/javascript" src="/assets/plugins/flot/jquery.flot.time.js"></script>
<script type="text/javascript" src="/assets/plugins/flot/jquery.flot.stack.js"></script>
<script type="text/javascript" src="/assets/js/for_index.js"></script>

</body>
</html>