<?php
echo gettoken();
function gettoken(){
	$cookie = tempnam('tmp','avo'.rand(1000000,9999999).'tmp.txt');
	$url = ("http://www.ocetiwakan.org/index.php?option=com_cmdonation&task=donation.submit");
    $content = curl($url,"amount=".rand(0,1000)."&anonymous=1&payment_method=paypalproexpress&campaign_id=1&return_url=aW5kZXgucGhwP2Zvcm1hdD1odG1sJm9wdGlvbj1jb21fY29udGVudCZ2aWV3PWFydGljbGUmaWQ9OTAmSXRlbWlkPTU0OQ==",0,1,"","",0,0,$cookie,0);
	$url = get_between($content,'If you are not redirected within 5 seconds please <a href="','"');
	$content = curl($url,0,0,1,"","",0,0,$cookie,0);
	$token = get_between($content,'"x-csrf-jwt": "','"');
    return $token;
}

function get_between($string, $start, $end) {
    $string = " ".$string;
    $ini = strpos($string,$start);
    if ($ini == 0) return "";
    $ini += strlen($start);
    $len = strpos($string,$end,$ini) - $ini;
    return substr($string,$ini,$len);
}

function curl($url, $fields="", $ssl = 0, $followLocation = 0, $referer = 'https://www.paypal.com', $optUrl = '',  $deleteOldCookies=1, $sock = false, $usecookie=false, $geturl=false) {
    $ch = curl_init($url);
    $header = array();
    $header[0]  = "Accept: text/xml,application/xml,application/xhtml+xml,";
    $header[0] .= "text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5";
    $header[0] .= "DNT: 1";
    $header[]   = "Connection: keep-alive";
    $header[]   = "Keep-Alive: 300";
    $header[]   = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $header[]   = "Accept-Language: en-us,en;q=0.5";
    $header[]   = "Pragma: "; // browsers keep this blank.
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 UBrowser/5.5.9936.1004 Safari/537.36");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	if ($usecookie) { 
	curl_setopt($ch, CURLOPT_COOKIEJAR, $usecookie); 
	curl_setopt($ch, CURLOPT_COOKIEFILE, $usecookie);    
	} 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    if($followLocation){
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    if($fields){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    }else{
        curl_setopt($ch, CURLOPT_POST, false);
    }
    if($referer){
        curl_setopt($ch, CURLOPT_REFERER, $referer);
    }else{
        curl_setopt($ch, CURLOPT_REFERER, $url);
    }
    if($ssl){
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    }else{
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    }
    if($optUrl){
        curl_setopt ($ch, CURLOPT_URL, $optUrl);
    }
	if($sock){
		curl_setopt($ch, CURLOPT_PROXY, $sock);
		curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
	}
	if($geturl == true){
		$xd1 = curl_exec($ch);
		$xd2 = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		echo $xd1."|".$xd2;
	} else {
		return curl_exec($ch);
	}
} 
?>