<?php
include('../../head.php');
?>
       <title>Ebay Email Valid Checker</title>
<?php

@set_time_limit(0);
function curl_($POSTFIELDS){
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://reg.ebay.com/reg/ajax"); 
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36");
curl_setopt($ch, CURLOPT_POSTFIELDS, $POSTFIELDS);
curl_setopt($ch, CURLOPT_REFERER, "https://reg.ebay.com/reg/PartialReg??_trksid=m570.l2621"); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 3);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
$result = curl_exec($ch); 
return $result;
curl_close($ch);
}
?>

<html>
<head><link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<title>Ebay Email Checker</title>
</head>
<body>
<div align="center">
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Ebay Email Valid Checker</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<form method="POST" name="akatsuki" action="">
<textarea id="text" name="mail" rows="10" cols="5" class="tool" style="width: 535px;margin-bottom: 5px;height: 120px;" placeholder="example@domain.com""><?php if(isset($_POST['mail'])){ echo $_POST['mail']; } ?></textarea><br>
<input type="submit" class="btn btn-success" value="Submit" name="sub" />
</form>
</div>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
</div>
<?php
include('function.php');
?>

</body>
 </div>
        <!--/.fluid-container-->
        <script src="/vendors/jquery-1.9.1.min.js"></script>
        <script src="/bootstrap/js/bootstrap.min.js"></script>
        <script src="/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="/assets/scripts.js"></script>
        <script>
</html>
