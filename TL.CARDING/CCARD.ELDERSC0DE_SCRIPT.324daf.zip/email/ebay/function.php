<?php
if(isset($_POST['sub'])){
$email_list=$_POST['mail'];
$line = explode("\r\n",$email_list);
$line = array_unique($line);
$j=0;$k=0;$o=0;
for($i=0;$i<count($line);$i++){
if (filter_var($line[$i], FILTER_VALIDATE_EMAIL)) {
   $rez=curl_($line[$i]);
echo "<font color='green'>".$line[$i]."";
$rez=curl_("email=".$line[$i]."&countryId=1&mode=5&eId=email");
if (strpos($rez,'Your email address is already registered with eBay' ) ){
echo "<font color='green'> Valid <br> </font>";
$live[$j]=$line[$i];
$j++;
}else{
echo "<font color='red'> Not Valid <br> </font>";
$die[$o]=$line[$i];
$o++;
}
}else{
echo "<font color='red'> Invalid mail </font>=>".$line[$i]."<br>";
$not[$k]=$line[$i];
$k++;
}

}
?>
<table border="0" width="100%">
<tr>
<td align='center' style="color:green"> Ebay Email (<?php echo @count($live);?>)</td>
<td align='center' style="color:red"> Not Ebay Email (<?php echo @count($die);?>)</td>
<td align='center' style="color:orange"> Invalid Email (<?php echo @count($not);?>)</td></tr>
<?php
if(isset($live)){ echo "<tr><td align='center' ><textarea cols='43' rows='10'>";for($i=0;$i<count($live);$i++){echo $live[$i]."\n"; } echo "</textarea></td>";}
if(isset($die)){ echo "<td align='center' ><textarea cols='43' rows='10'>";for($i=0;$i<count($die);$i++){echo $die[$i]."\n"; } echo "</textarea></td>";}else{echo "<td align='center' ><textarea cols='43' rows='10'></textarea>"; }
if(isset($not)){ echo "<td align='center' ><textarea cols='43' rows='10'>";for($i=0;$i<count($not);$i++){echo $not[$i]."\n"; } echo "</textarea></td><tr></table>";}else{echo "<td align='center' ><textarea cols='43' rows='10'></textarea>";}
} 
?>