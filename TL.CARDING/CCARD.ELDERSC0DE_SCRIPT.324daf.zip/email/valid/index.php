<?php
include('../../head.php');
?>
<title>Paypal Email Valid Checker Gate 1</title>
<link href="/favicon.ico" rel="icon" type="image/x-icon" />

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
String.prototype.contains = function(it) 
{ 
   return this.indexOf(it) != -1; 
};
$(document).ajaxStop(function() {
    alert("Check Done!");
    $("#cok").text($("#ok").find('br').length);
    $("#cbad").text($("#bad").find('br').length);
});
$(document).ready(function(){
    var st;
    $("#start").click(function(){
        $("#ok").text("");
        $("#bad").text("");
        var em = $("#pop").val().split("\n");
        var i = 0;
        for (i = 0; i < em.length; i++){
           if(em[i] != ""){
               st = $.post("function.php",{
                        ue: em[i]
                    },function(data){
                        if(data.search("color=red") >= 0){
                            if(i == 0){
                                $("#bad").text(data+"<br>");
                            }else{
                                $("#bad").append(data+"<br>");
                            }
                        }else{
                            if(i == 0){
                                $("#ok").text(data+"<br>");
                            }else{
                                $("#ok").append(data+"<br>");
                            }
                       }
                     $("#counter").text(i);
               });
           }
        }
    });
    $("#stop").click(function(){
	var em = $("#pop").val().split("\n");
        var i = 0;
    	for (i = 0; i < em.length; i++){
    		st.abort();
    	}
    });
});
</script>
</head>
<body>
</a>				
</a>				
				
        </dt>
        </center>
                <!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div><center><b>Paypal Email Valid Checker Gate 1</b></center></div>
                                </div>
                                <div class="block-content collapse in">
<center><textarea id=pop name='val' class rows="10" cols="5" class="tool" style="width: 535px;margin-bottom: 5px;height: 120px;" placeholder="example@domain.com"></textarea><br><br>
<div class="col-lg-4">
<button class="btn btn-success" id="start">Submit</button>
<button class="btn btn-danger" id="stop">Stop</button><br></center>
</form>
</div>
</div>
</div>
<!--/span-->
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Live </b></font><span class="badge badge-success" class="pull-right" id="cok">0</span></div>
                                </div>
                                <div class="block-content collapse in">
<span id="ok" style="overflow-y:auto; width:500px; font-size: 11px;"></span><div id="pplive">
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">
        <font color="black"><i class="icon-th-list"></i><b> Die </b></font><span class="badge badge-important" class="pull-right" id="cbad">0</span></div>
                                </div>
                                <div class="block-content collapse in">
        <span id="bad" style="overflow-y:auto; width:500px; font-size: 11px;"></span><div id="ppdie"></div>
</div>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                                </div>
                            </div>
<center><script id="_waupw2">var _wau = _wau || [];
_wau.push(["tab", "u8tylhw1w8yn", "pw2", "right-upper"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script></center>
</body>