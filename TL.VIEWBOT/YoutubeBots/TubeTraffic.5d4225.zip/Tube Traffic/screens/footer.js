﻿$(function () {

    $("#deletetask").click(function () {

        window.external.lnkClear_Click();
    });
    $("#starttask").click(function () {
       var txt = $("#starttask").attr("title");
       window.external.btnStart_Click(txt);
    });
    
});

function SetPendingTask(pendingtask)
{
    $("#pending").text(pendingtask);
}
function SetStartTask(data,data1) {
    $("#msg").text("");
   
        $("#starttask").attr("title", data);
        $("#starttask").html(data1);
    }
//function Setmessage(data) {
    
//    $("#msg").text(data);
   
//}
function Setmessage(data) {
    $("#msg").text(data);
    $("#msg").fadeIn('slow');
    setTimeout(function () { outmesage('msg') }, 3000);
}
function outmesage(data) {
    $("#" + data).fadeOut('slow');
}