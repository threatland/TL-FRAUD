﻿

            $(function () {
                

                $(".harvestvideo").click(function () {
                   
                    window.external.HarvestVideos();
                })
                $("a.error").live('click', function () {
                 
                    var id = $(this).attr('id').substr(3);
                    window.external.ShowError(id);
                });

                $(".addvid").click(function () {
                    window.external.AddVideoManually();
                });

                $(".finduser").click(function () {
                    window.external.FindUserVideos();
                });

                $(".findkeyword").click(function () {
                    window.external.FindKeywordVideos();
                });
                $(".findpage").click(function () {
                    window.external.HarvestVidsFromPage();
                });


                $(".findtop").click(function () {
                    window.external.FindVidsFromTop();
                });

                $(".harvestedvids").click(function () {
                    window.external.HarvestedVideos();
                });

                $("#cancel").click(function () {
                    window.external.Closethis();
                });

               

                $('#submit').click(function () {
                    if (harvestvideourl(true)) {
                        window.external.AddVideoURL($("#videolists").val(), $("#videourl").val());
                    }
                });

                $("#submitnew").click(function () {
                    if (harvestvideourl(false)) {
                        window.external.AddVideoURL($("#newgrouptxt").val(), $("#videourl").val());
                    }
                });



                $('#submitvideokey').click(function () {
                    if (validate()) {
                        window.external.FindKeywords($("#keyword").val(), $("#videolists").val(), $("#resultcount").val());
                    }
                });

                $("#submitnewvideokey").click(function () {
                    window.external.FindKeywords($("#keyword").val(), $("#newgrouptxt").val(), $("#resultcount").val());
                });


                $('#submituservideo').click(function () {
                    if (finduservideo()) {
                        window.external.FindVideoUsers($("#userid").val(), $("#videolists").val(), $("#resultcount").val());
                    }
                });

                $("#submitnewuservideo").click(function () {
                    if (finduservideo()){ window.external.FindVideoUsers($("#userid").val(), $("#newgrouptxt").val(), $("#resultcount").val());
                    }

                });



                $('#submittops').click(function () {
                    if (videotops()) {
                        window.external.HarvestTops($("input[type='radio']:checked").attr("value"), $("#videolists").val(), $("#resultcount").val());
                    }
                });

                $("#submitnewtops").click(function () {
                    if (videotops()) {
                        window.external.HarvestTops($("input[type='radio']:checked").attr("value"), $("#newgrouptxt").val(), $("#resultcount").val());
                    }
                });


                $('#submitvideopage').click(function () {
                    if (videourl()) {
                        window.external.HarvestPages($("#url").val(), $("#videolists").val());
                    }
                });
                $("#submitnewvideopage").click(function () {
                    if (videourl()) {
                        window.external.HarvestPages($("#url").val(), $("#newgrouptxt").val());
                    }
                });


                $(".open").live('click', function () {
                    window.external.ShowLink($(this).attr('vidurl'));
                });



                $("#harvestedusers").click(function () {
                    window.external.HarvestedUsers();
                });


                $(".vgroup").live('click', function () {
                    var id = $(this).attr('id');
                    window.external.ShowUsers(id, 1, true);
                });


                $("#savevidlist").click(function () {
                    window.external.SaveVideoList();
                });



            });



       
            function harvestvideourl(data) {

                var ulval = "";
                if (data) {
                     ulval = $("#videolists").val();
                }
                else{
                    ulval = $("#newgrouptxt").val();
                }
                var uid = $("#videourl").val().trim();

                if(uid == null || uid.trim() == "" || uid.trim().length == 0)
                {
                    alert("Please provide a video URL!");
                    $("#videourl").val("");
                    $("#videourl").focus();
                    return false;
                }

                if (ulval == 0 || ulval == "" || ulval.trim().length == 0) {
                    alert("Please provide a video group!")
                    return false;
                }
                return true;
            }

            function validate() {
                var ulval = $("#videolists").val();
                var ultxt = $("#newgrouptxt").val();
                var kword = $("#keyword").val().trim();

                if (kword == "") {
                    alert("Please provide a keyword!");
                    $("#videourl").val("");
                    $("#videourl").focus();
                    return false;
                }

                if (ulval == "0" && ultxt == "") {
                    alert("Please provide a video group!")
                    return false;
                }
                return true;
            }

            function finduservideo() {
                var ulval = $("#videolists").val();
                var ultxt = $("#newgrouptxt").val();
                var uid = $("#userid").val().trim();

                if (uid == "") {
                    alert("Please provide a user ID!");
                    $("#userid").focus();
                    return false;
                }

                if (ulval == "0" && ultxt == "") {
                    alert("Please provide a video group!")
                    return false;
                }
                return true;
            }

            function videotops() {
                var vidval = $("#videolists").val();
                var ultxt = $("#newgrouptxt").val();

                if (vidval == "0" && ultxt == "") {
                    alert("Please provide a video group.")
                    return false;
                }
                return true;
            }
            function videourl() {
                var ulval = $("#videolists").val();
                var ultxt = $("#newgrouptxt").val();
                var url = $("#url").val().trim();

                if (url == "") {
                    alert("Please provide a URL.");
                    $("#url").val("");
                    $("#url").focus();
                    return false;
                }

                if (ulval == "0" && ultxt == "") {
                    alert("Please provide a video group.")
                    return false;
                }
                return true;
            }





            function videotask(data) {
                var showvedio = JSON.parse(data);
                // alert(showuser);
                var templete = $("#GroupVideoTemplate").html();
                $("#tbodyvideobody").html("");
                 Mustache.parse(templete);
                for (var i = 0; i < showvedio.length; i++) {
                   
                   
                    var rendered = Mustache.render(templete, showvedio[i]);
                   
                    $("#tbodyvideobody").append(rendered);
                }

            }



            function Vdlisttask(data) {
                var VDList = JSON.parse(data);
                var templete = $("#GroupVedioTemplate").html();
                $("#Vdlisttask").html("");
                for (var i = 0; i < VDList.length; i++) {
                    Mustache.parse(templete);
                   
                    VDList[i].ViewCount = updateNumber(VDList[i].ViewCount);
                    var rendered = Mustache.render(templete, VDList[i]);
                   
                    $("#Vdlisttask").append(rendered);
                }
                
            }

            $(function () {
                $("#empty").click(function () {
                    window.external.DeleteOldData();
                });

            });

    
            function reporttask(data) {
                var report = JSON.parse(data);
      
                var templete = $("#reporttasktr").html();

                $("#reporttask").html("");
                Mustache.parse(templete);
                for (var i = 0; i < report.length; i++) {
                  
                    var jobj = report[i];
                    jobj.count = i + 1;
                    Mustache.parse(templete);
                   
                   
                    var rendered = Mustache.render(templete, jobj);
                    
                    $("#reporttask").append(rendered);
                 
                }

            }

         

            function updateNumber(strNumber) {
                return window.external.ConvertToNumberString(strNumber);
            }