﻿

            $(function () {
                

                $(".btnuseint").click(function () {
                   
                    window.external.UserInteractions();
                })

                $(".usersub").click(function () {
                    window.external.UserSub();
                });

                $(".uservidshare").click(function () {
                    window.external.UserVidShare();
                });

                $('#submit').click(function () {
                    if (shareurl()) {
                        window.external.ShareVideo($("#vidurl").val());
                    }
                });

                $(".cancel").click(function () {
                    window.external.Closethis();
                });


                $('#submitsub').click(function () {
                    if (validate()) {
                        window.external.SubscribeUser($("#userlists").val(), $("#googaccs").val(), $("#reqcount").val());
                    }
                });

                $(".cancel").click(function () {
                    window.external.Closethis();
                });

                $("#modifygacc").click(function () {
                    var commgroup = $("#googacclist option:selected").val();
                    window.external.ManageGAcc();
                });

            });



            function shareurl() {
                var vidurl = $("#vidurl").val();

                if (vidurl == "") {
                    alert("Please provide a video URL!");
                    return false;
                }
                return true;
            }

            function validate() {
                var ulval = $("#userlists").val();
                var gacc = $("#googaccs").val();

                if (ulval == "0") {
                    alert("Please select a user group!");
                    return false;
                }
                if (gacc == "0") {
                    alert("Please select a google account!")
                    return false;
                }
                return true;
            }