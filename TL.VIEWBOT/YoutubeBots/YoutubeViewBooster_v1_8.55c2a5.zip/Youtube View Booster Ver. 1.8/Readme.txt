This program was coded by idulkoan

[What it Does]
This Program Helps Give You Youtube Views.

[Usage]
Copy and paste the youtube URL You would like to boost to the 'Video URL:' Box in the Program. 
Import a Proxy list [.txt] 
[ ip format:
ip:port
ip:port
ip:port
ip:port ]
Click 'Start boosting', and watch the 'Video Preview' to confirm its refreshing/boosting the page. Leave it running, and watch your view count. To stop the Booster, Just simply click 'Stop Boosting'. 
(Instructions also on the bottom of the Booster Window)

[Updates]
To update the Program, click 'Check For Updates' on the top right corner next to the Booster Version Number. Then Click 'Check For Updates' again on the new window that pops up. Your Default internet browser will open with the Booster Downloads page. Look for the highest version number avaliable, download, and delete the lower version of the Program. Updates will have bug fixes, and newer features. 

[Contact]
You can contact me at idulkoan@yahoo.com or you can PM Me on youtube (Youtube username: idulkoan)
Follow my twitter @idulkoan

[Program doesn't start, or you get an error]
If this program doesn't start, or you get an error, download the latest version of Microsoft .NET Framework on the Official Microsoft Website. 