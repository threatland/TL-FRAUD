To make the unit tests and sample app work, they need to be able to find a matching version of Firefox or XulRunner.  If you go the XulRunner route, download it and place it in this folder.  You can get it from http://ftp.mozilla.org/pub/mozilla.org/xulrunner/releases/. Unzip the "xulrunner" folder so that you have


PutXulRunnerFolderHere\xulrunner\

