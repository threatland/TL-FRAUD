﻿
            $(function () {
                $("#btnabout").click(function () {
                    window.external.About();
                });
                $("#btnexit").click(function () {
                    window.external.Exit();
                });
                $("#btnhelp").click(function () {
                    window.external.Help();
                });

                $("#btnharvuser, #maphrvuse").click(function () {
                    window.external.HarvestUsers();
                });

                $("#btnharvvid, #maphrvvid").click(function () {
                    
                    window.external.HarvestVideos();
                });

                $("#btnuseint, #mapuseint").click(function () {
                    
                    window.external.UserInteractions();
                });

                $("#btnvidint, #mapvidint").click(function () {

                    window.external.VideoInteractions();
                });

                $("#btnSettings").click(function () {
                    window.external.Settings();
                });

                $("#btnReports").click(function () {
                    window.external.ShowReport();
                });

                $("#refresh").click(function () {
                    window.external.RefreshStats();
                });
               
                $("#home").click(function() {
                    window.external.Homepage();
                });

                

                $("#add").click(function () {
                    $("#selgroup").hide();
                    $("#newgroup").show();
                });

                $("#selold").click(function () {
                    $("#selgroup").show();
                    $("#newgroup").hide();
                });

                $(".cancel").click(function () {
                    window.external.Closethis();
                });

                $("#userlists").change(function () {
                    if ($("#userlists option:selected").val() != 0) {
                        $("#delete").show();
                    }
                    else $("#delete").hide();
                });

                $("#delete").click(function () {
                    window.external.DeleteGroup($("#userlists").val());
                });


                $("#videolists").change(function () {
                    if ($("#videolists option:selected").val() != 0) {
                        $("#deletevideo").show();
                    }
                    else $("#deletevideo").hide();
                });

               

                $("#deletevideo").click(function () {
                    window.external.DeleteGroup($("#videolists").val());
                });

            });

          

            function RenderGroupCount() {
               
                $('#tbodyuserlbody').html("");
                $('#tbodyvideobody').html("");

                var userlist = $.parseJSON(window.external.BindIndexUser.ToString());
                var videolist = $.parseJSON(window.external.BindIndexVideo.ToString());
                for (var i = 0; i < userlist.length; i++) {
                    var template = $('#GroupUserTemplate').html();
                    Mustache.parse(template);   // optional, speeds up future uses
                    
                    var rendered = Mustache.render(template, userlist[i]);
                   
                    $('#tbodyuserlbody').append(rendered);
                }
               
              
                if (userlist.length == 0) {
                    $("#tbodyuserlbody").html("There is no data yet.").show();
                }
                for (var i = 0; i < videolist.length; i++) {
                    
                    var template = $('#GroupVideoTemplate').html();
                    Mustache.parse(template);   // optional, speeds up future uses

                    var rendered = Mustache.render(template, videolist[i]);
                    
                    $('#tbodyvideobody').append(rendered);
                }
                if (videolist.length == 0) {
                    $("#tbodyvideobody").html("There is no data yet.").show();
                }
                
            }

            $(function () {
               
                resize();

                //$(document)
                //    .resize(function () {
                //        resize();
                //    });

            });

            function resize() {
             
                //if ($(".container").is(".wraper")) {
                    
                var screenHeight = screen.height;
            
                    //var topHeight = $(".wraper").height();
                    //var menuHeight = $(".sidebarmenu").height() - 350;

                   // var total = topHeight - 330 ;
                    //var total = topHeight + menuHeight + 280;
                    var remain = (screenHeight - 320)+60;
                  
                    $("#tabwrapper").css('height', remain + "px");
               // }
            }
