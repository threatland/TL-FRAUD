﻿

            $(function () {
                
                $("#addnamegroup").click(function () {
                    var grpname = $("#grpname").val();

                    if (grpname.length > 0) {
                        var res = window.external.AddNewGroup(grpname);
                    }
                    else {
                        alert("Please provide a group name!");
                    }
                }); 


                $("#cancel").click(function () {
                    window.external.Closethis();
                    return false;
                });
                $("#savecomment").click(function () {
                    window.external.Closethis();
                    return false;
                });

                $(".cmddlt").live('click', function () {
                    var cmtid = $(this).siblings('.cmtid').eq(0).attr('value');
                   
                    window.external.DeleteComment(cmtid);
                    return false;
                });

                $("#addcomment").click(function () {
                    window.external.AddComment();
                    return false;
                });



                $("#cancel").click(function () {
                    window.external.Closethis();
                });

                $("#submitadd").click(function () {
                    
                    var txt = $("#cmttxt").val();

                    if (txt.length > 0) {
                        window.external.SaveComment(txt);
                    }
                    else {
                        alert("Please type a comment first!");
                    }
                });




                $(".btnvidint").click(function () {
                   
                    window.external.VideoInteractions();
                })

                $(".uservids").click(function () {
                    window.external.GetCommentUsers();
                });

                $(".relatedvids").click(function () {
                    window.external.GetRelatedVideos();
                });

                $(".postvidcomment").click(function () {
                    window.external.PostVidComments();
                });

                $('#submit').click(function () {
                    if (videourl()) {
                        window.external.FindCommentUsers($("#userlists").val(), $("#videourl").val(), $("#resultcount").val());
                    }
                });

                $("#submitnew").click(function () {
                    if (videourl()) {
                        window.external.FindCommentUsers($("#newgrouptxt").val(), $("#videourl").val(), $("#resultcount").val());
                    }
                });


                $('#submitrelatedvid').click(function () {
                    if (relatedvideourl()) {
                        window.external.GetRelVideos($("#videolists").val(), $("#videourl").val());
                    }
                });

                $("#submitnewrelatedvid").click(function () {
                    if (relatedvideourl()) {
                        window.external.GetRelVideos($("#newgrouptxt").val(), $("#videourl").val());
                    }
                });




                $('#submitpost').click(function () {
                    if (postcomment()) {
                        window.external.PostVidComment($("#videolists").val(), $("#commentlists").val(), $("#googacclist").val(), $("#reqcount").val());
                    }
                });

                $("#newcomment").click(function () {
                   
                    window.external.NewCommentGroup();
                });

                $(".cancel").click(function () {
                    window.external.Closethis();
                });

                $("#commentlists").change(function () {
                    if ($("#commentlists option:selected").val() != 0) {
                        $("#modifycommgroup").show();
                        $("#delcommgroup").show();
                    }
                    else {
                        $("#modifycommgroup").hide();
                        $("#delcommgroup").hide();
                    }
                });

                $("#modifycommgroup").click(function () {
                    var commgroup = $("#commentlists option:selected").val();
                    window.external.ModifyCommentGroup(commgroup);

                });

                $("#delcommgroup").click(function () {
                    var commgroup = $("#commentlists option:selected").val();
                    window.external.DeleteCommentGroup(commgroup);
                });

                $("#modifygacc").click(function () {
                    var commgroup = $("#googacclist option:selected").val();
                    window.external.ManageGAcc();
                });

            });


            function videourl() {
                var ulval = $("#userlists").val();
                var ultxt = $("#newgrouptxt").val();
                var uid = $("#videourl").val().trim();

                if (uid == "") {
                    alert("Please provide a video URL!");
                    $("#videourl").val("");
                    $("#videourl").focus();
                    return false;
                }

                if (ulval == "0" && ultxt == "") {
                    alert("Please provide a user group!")
                    return false;
                }
                return true;
            }

            function relatedvideourl() {
                var ulval = $("#videolists").val();
                var ultxt = $("#newgrouptxt").val();
                var vidurl = $("#videourl").val().trim();

                if (vidurl == "") {
                    alert("Please provide a video URL!");
                    $("#videourl").val("");
                    $("#videourl").focus();
                    return false;
                }

                if (ulval == "0" && ultxt == "") {
                    alert("Please provide a video group!")
                    return false;
                }
                return true;
            }


            function postcomment() {
                var ulval = $("#videolists").val();
                var cmval = $("#commentlists").val();
                var gval = $("#googacclist").val();

                if (ulval == 0) {
                    alert("Please select a video group!")
                    return false;
                }
                if (cmval == 0) {
                    alert("Please select a comment group!")
                    return false;
                }
                if (gval == 0) {
                    alert("Please select a google account to use!")
                    return false;
                }
                return true;
            }
