﻿

$(function () {
                
    $(".adduserscreen").click(function () {
                   
        window.external.HarvestUsers();
    })
               
    $(".adduser").click(function() {
        window.external.Adduser();
    });
    $(".findkeywords").click(function () {
        window.external.FindKeywordUser();
    });

    $(".harvestpage").click(function () {
        window.external.HarvestPage();
    });

    $(".harvesttops").click(function () {
        window.external.HarvestTops();
    });
    $(".harvestedusers").click(function () {
        window.external.HarvestedUsers();
    });



    $('#submit').click(function () {
        if (validatekeyword()) {
            window.external.FindKeywords($("#keyword").val(), $("#userlists").val(), $("#resultcount").val());
        }
    });

    $("#submitnew").click(function () {
        if (validatekeyword()) {
            window.external.FindKeywords($("#keyword").val(), $("#newgrouptxt").val(), $("#resultcount").val());
        }
    });
    

    $('#submitadduser').click(function () {
        if (adduserid(false)) {
            window.external.AddUserID($("#userlists").val(), $("#userid").val().trim());
        }
    });

    $("#submitnewadduser").click(function () {
        if (adduserid(true)) { 
            window.external.AddUserID($("#newgrouptxt").val(), $("#userid").val());
        }
    });

    $('#submiturl').click(function () {
        if (validateaddurl()) {
            window.external.HarvPage($("#url").val(), $("#userlists").val());
        }
    });

    $("#submitnewurl").click(function () {
        if (validateaddurl()) {
            window.external.HarvPage($("#url").val(), $("#newgrouptxt").val());
        }
    });



    $('#submittops').click(function () {
        if (validatetops()) {
            window.external.HarvestTop($("input[type='radio']:checked").attr("value"), $("#userlists").val(), $("#resultcount").val());
        }
    });
    $("#submitnewtops").click(function () {
        if (validatetops()) {
            window.external.HarvestTop($("input[type='radio']:checked").attr("value"), $("#newgrouptxt").val(), $("#resultcount").val());
        }
    });


    $("#harvestedusers").click(function () {
        window.external.HarvestedUsers();
    });


    $(".ugroup").live('click', function () {
        var id = $(this).attr('id');
      
        window.external.ShowUsers(id,1,false);
    });


    $("#ugrp").click(function () {
        $("#userlist").hide();
        $("#newuserlist").show();
    });

    $("#nextpage").click(function () {
        window.external.GoToNextPage();
    });

    $("#prevpage").click(function () {
        window.external.GoToPrevPage();
    });

    $("#saveuserlists").click(function () {
        window.external.SaveUserList();
    });

  
   



});




function validatekeyword() {
    var ulval = $("#userlists").val();
    var ultxt = $("#newgrouptxt").val();
    var kword = $("#keyword").val().trim();

    if (kword == "") {
        alert("Please provide a keyword!");
        $("#keyword").val("");
        $("#keyword").focus();
        return false;
    }

    if (ulval == "0" && ultxt == "") {
        alert("Please provide a user group!")
        return false;
    }
    return true;
}


function adduserid(data) {
    var ultxt = "";
    
    if (!data) {
        ultxt = $("#userlists").val();
    }
    else {
        ultxt = $("#newgrouptxt").val();
    }
  
    var uid = $("#userid").val().trim();

    if (uid == null || uid.trim() == "" || uid.trim().length == 0) {
        
       alert("Please provide a user id!");
        $("#userid").val("");
        $("#userid").focus();
        return false;
    }
  
    if (ultxt == 0 || ultxt == "" || ultxt.trim().length == 0) {
        alert("Please provide a user group!")
        return false;
    }

    return true;
}

function validateaddurl() {
    var ulval = $("#userlists").val();
    var ultxt = $("#newgrouptxt").val();
    var url = $("#url").val().trim();

    if (url == "") {
        alert("Please provide a URL!");
        $("#url").val("");
        $("#url").focus();
        return false;
    }

    if (ulval == "0" && ultxt == "") {
        alert("Please provide a user group!")
        return false;
    }
    return true;
}

function validatetops() {
    var ulval = $("#userlists").val();
    var ultxt = $("#newgrouptxt").val().trim();

    if (ulval == "0" && ultxt == "") {
        alert("Please provide a user group!")
        $("#newgrouptxt").val("");
        $("#newgrouptxt").focus();
        return false;
    }
    return true;
}

function SetPendingTask1(data) {
    var showuser = JSON.parse(data);
  
    var templete = $("#GroupUserTemplate").html();
    $("#tbodyuserlbody").html("");
   for (var i = 0; i < showuser.length; i++) {
        Mustache.parse(templete);
        var rendered = Mustache.render(templete, showuser[i]);
       
        $("#tbodyuserlbody").append(rendered);
    }

}

function userlisttask(data) {

    var showlist = JSON.parse(data);
    var templete = $("#ListTempleate").html();
    $("#listdata").html("");
    for (var i = 0; i < showlist.length; i++) {
        showlist[i].Subscriber = updateNumber(showlist[i].Subscriber);
        showlist[i].TotalVideo = updateNumber(showlist[i].TotalVideo);
        showlist[i].TotalComments = updateNumber(showlist[i].TotalComments);
        showlist[i].Views = updateNumber(showlist[i].Views);
        Mustache.parse(templete);
        var rendered = Mustache.render(templete, showlist[i]);
        
        $("#listdata").append(rendered);
    }


}
