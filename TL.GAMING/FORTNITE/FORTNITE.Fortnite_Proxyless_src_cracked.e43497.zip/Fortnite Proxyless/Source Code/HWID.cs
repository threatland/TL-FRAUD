using System;
using System.Management;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace kappa
{
	[Obfuscation(Feature="virtualization", Exclude=false)]
	internal class HWID
	{
		private string BIOS
		{
			get;
			set;
		}

		private string CPU
		{
			get;
			set;
		}

		private string GPU
		{
			get;
			set;
		}

		private string HardwareID
		{
			get;
			set;
		}

		private string HDD
		{
			get;
			set;
		}

		private bool IsServer
		{
			get;
			set;
		}

		private string MAC
		{
			get;
			set;
		}

		private string OS
		{
			get;
			set;
		}

		private string SCSI
		{
			get;
			set;
		}

		public HWID()
		{
			this.BIOS = HWID.GetWMIIdent("Win32_BIOS", new string[] { "Manufacturer", "SMBIOSBIOSVersion", "IdentificationCode" });
			this.CPU = HWID.GetWMIIdent("Win32_Processor", new string[] { "ProcessorId", "UniqueId", "Name" });
			this.HDD = HWID.GetWMIIdent("Win32_DiskDrive", new string[] { "Model", "TotalHeads" });
			this.GPU = HWID.GetWMIIdent("Win32_VideoController", new string[] { "DriverVersion", "Name" });
			this.MAC = HWID.GetWMIIdent("Win32_NetworkAdapterConfiguration", "MACAddress");
			this.OS = HWID.GetWMIIdent("Win32_OperatingSystem", new string[] { "SerialNumber", "Name" });
			this.SCSI = HWID.GetWMIIdent("Win32_SCSIController", new string[] { "DeviceID", "Name" });
			this.IsServer = this.HDD.Contains("SCSI");
			this.HardwareID = this.Build();
		}

		private string Build()
		{
			string str = string.Concat(new string[] { this.BIOS, this.CPU, this.HDD, this.GPU, this.MAC, this.SCSI });
			if (str == null)
			{
				Console.WriteLine("Could not resolve hardware informations...");
			}
			string base64String = Convert.ToBase64String((new SHA1CryptoServiceProvider()).ComputeHash(Encoding.Default.GetBytes(str)));
			return base64String;
		}

		[DllImport("user32.dll", CharSet=CharSet.None, ExactSpelling=false)]
		internal static extern bool CloseClipboard();

		public void Copy()
		{
			HWID.OpenClipboard(IntPtr.Zero);
			IntPtr hGlobalUni = Marshal.StringToHGlobalUni((this.HardwareID == null ? this.Build() : this.HardwareID));
			HWID.SetClipboardData(13, hGlobalUni);
			HWID.CloseClipboard();
			Marshal.FreeHGlobal(hGlobalUni);
		}

		public static string Get()
		{
			return (new HWID()).HardwareID;
		}

		private static string GetWMIIdent(string Class, string Property)
		{
			string str = "";
			foreach (ManagementBaseObject instance in (new ManagementClass(Class)).GetInstances())
			{
				string propertyValue = instance.GetPropertyValue(Property) as string;
				str = propertyValue;
				if (propertyValue != "")
				{
					break;
				}
			}
			return str;
		}

		private static string GetWMIIdent(string Class, params string[] Propertys)
		{
			string str = "";
			Array.ForEach<string>(Propertys, (string prop) => str = string.Concat(str, HWID.GetWMIIdent(Class, prop), " "));
			return str;
		}

		public string HWIDToStr()
		{
			return this.HardwareID;
		}

		private bool IsWinServer()
		{
			return this.OS.Contains("Microsoft Windows Server");
		}

		[DllImport("user32.dll", CharSet=CharSet.None, ExactSpelling=false)]
		internal static extern bool OpenClipboard(IntPtr hWndNewOwner);

		[DllImport("user32.dll", CharSet=CharSet.None, ExactSpelling=false)]
		internal static extern bool SetClipboardData(uint uFormat, IntPtr data);

		public override string ToString()
		{
			return string.Format("Hardware ID {0} Copied to Clipboard", this.HardwareID);
		}
	}
}